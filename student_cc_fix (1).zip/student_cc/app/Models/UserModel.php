<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'user';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['id', 'username', 'password', 'role', 'created_at'];
    protected $useTimestamps = true;

    public function generateIdUser()
    {
        // Ambil data terakhir berdasarkan ID dengan format yang sesuai
        $UserTerakhir = $this->select('id')->orderBy('id', 'DESC')->first();

        if ($UserTerakhir && isset($UserTerakhir['id'])) {
            // Pastikan ID diawali huruf 'S' dan ambil angka di belakangnya
            $idBaru = $UserTerakhir['id'] + 1;
        } else {
            // Jika belum ada data, mulai dari ID 'S001'
            $idBaru = 1;
        }

        return $idBaru;
    }

    function getAllUser($limit = null, $offset = null)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('user');
        $builder->select('user.id, user.username, user.password, user.role');
        $builder->orderBy('user.id', 'ASC');

        if ($limit !== null) {
            $builder->limit($limit, $offset);
        }

        return $builder->get()->getResultArray();
    }

    public function getTotalUser()
    {
        return $this->db->table('user')->countAllResults();
    }
}
