<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $table            = 'mahasiswa';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['id_user', 'nim', 'nama', 'id_prodi', 'created_at'];
    protected $useTimestamps = true;

    function getAllMahasiswa($limit = null, $offset = null)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('mahasiswa');
        $builder->select('mahasiswa.id as mahasiswa_id, mahasiswa.id_user, mahasiswa.nim, mahasiswa.nama, mahasiswa.id_prodi, prodi.prodi as nama_prodi, prodi.kelas, prodi.tingkat, user.id as user_id, user.username, user.role');
        $builder->join('prodi', 'prodi.id = mahasiswa.id_prodi', 'left');
        $builder->join('user', 'user.id = mahasiswa.id_user', 'left');
        $builder->orderBy('mahasiswa.id', 'ASC');

        if ($limit !== null) {
            $builder->limit($limit, $offset);
        }

        return $builder->get()->getResultArray();
    }

    public function getTotalMahasiswa()
    {
        return $this->db->table('mahasiswa')->countAllResults();
    }

    public function getMahasiswa()
    {
        $session = session();
        $username = $session->get('username');

        if (empty($username)) {
            return null;
        }

        return $this->db->table('mahasiswa')
            ->select('mahasiswa.*')
            ->join('user', 'user.id = mahasiswa.id_user')
            ->where('mahasiswa.nim', $username)
            ->get()
            ->getResultArray();
    }

    public function getMahasiswaWithUser($mahasiswa_id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('mahasiswa');
        $builder->select('mahasiswa.*, prodi.prodi as nama_prodi, prodi.kelas, prodi.tingkat, user.*');
        $builder->join('prodi', 'prodi.id = mahasiswa.id_prodi', 'left');
        $builder->join('user', 'user.id = mahasiswa.id_user', 'left');
        $builder->where('mahasiswa.id', $mahasiswa_id);

        return $builder->get()->getRowArray();
    }
}
