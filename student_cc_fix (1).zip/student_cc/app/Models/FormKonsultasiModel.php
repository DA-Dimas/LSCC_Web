<?php

namespace App\Models;

use CodeIgniter\Model;

class FormKonsultasiModel extends Model
{
    protected $table            = 'konsultasi';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'id_mahasiswa',
        'id_dosen',
        'id_kategori',
        'tanggal_konsultasi',
        'jam_mulai',
        'jam_selesai',
        'status',
        'keterangan',
        'updated_by',
        'catatan',
        'solusi',
        'created_at',
        'updated_at'
    ];
    protected $useTimestamps = true;

    function getMahasiswa()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('konsultasi');

        // Dapatkan id dosen yang sedang login dari session
        $session = session();
        $id_dosen = $session->get('id_dosen'); // pastikan session 'id_dosen' tersedia

        // Pilih kolom yang diperlukan dan buat alias
        $builder->select('konsultasi.*, mahasiswa.nama as nama_mahasiswa, mahasiswa.nim, kategori.kategori');

        // Lakukan JOIN dengan tabel mahasiswa
        $builder->join('mahasiswa', 'mahasiswa.id = konsultasi.id_mahasiswa', 'left');

        // Lakukan JOIN dengan tabel kategori
        $builder->join('kategori', 'kategori.id = konsultasi.id_kategori', 'left');

        // Filter data konsultasi sesuai dengan dosen yang sedang login
        $builder->where('konsultasi.id_dosen', $id_dosen);

        // Perbaikan penulisan variabel builder dan pengurutan descending berdasarkan kolom 'id'
        $builder->orderBy('konsultasi.id', 'DESC');

        // Ambil data dan kembalikan dalam bentuk array
        $query = $builder->get()->getResultArray();

        return $query;
    }


    public function getTotalKonsultasi()
    {
        return $this->db->table('konsultasi')
            ->where('konsultasi.catatan IS NOT NULL AND konsultasi.catatan != ""')
            ->where('konsultasi.solusi IS NOT NULL AND konsultasi.solusi != ""')
            ->countAllResults();
    }

}
