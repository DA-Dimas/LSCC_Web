<?php

namespace App\Models;

use CodeIgniter\Model;

class DosenModel extends Model
{
    protected $table            = 'dosen';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['id_user', 'nidn', 'nama', 'foto', 'jabatan', 'no_wa', 'instagram', 'created_at'];
    protected $useTimestamps = true;

    public function getTotalKonseler()
    {
        return $this->db->table('dosen')->countAllResults();
    }

    public function getDosenBySession()
    {
        $session = session();
        $username = $session->get('username');

        if (empty($username)) {
            return null;
        }

        $db = \Config\Database::connect();
        return $db->table('dosen')
            ->select('dosen.*')
            ->join('user', 'user.id = dosen.id_user')
            ->where('user.username', $username)
            ->get()
            ->getRowArray();
    }

    public function getAllDosenWithUser()
    {
        return $this->db->table('dosen')
            ->select('dosen.*')
            ->join('user', 'user.id = dosen.id_user')
            ->where('user.role', 'Dosen')
            ->get()
            ->getResultArray();
    }
}
