<?php

namespace App\Models;

use CodeIgniter\Model;

class KelasModel extends Model
{
    protected $table            = 'kelas';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['id_prodi', 'kelas', 'tingkat'];

    function getProdi()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('kelas');
        $builder->select('kelas.*, prodi.prodi as prodi');
        $builder->join('prodi', 'prodi.id = kelas.id_prodi', 'left');

        return $builder->get()->getResultArray();
    }
}
