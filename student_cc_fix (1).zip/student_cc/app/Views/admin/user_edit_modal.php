<!-- Form Edit User -->
<input type="hidden" class="form-control" name="user_id" value="<?= esc($user['id']) ?>" required>

<div class="mb-3">
    <label>Username</label>
    <input type="text" value="<?= esc($user['username']) ?>" placeholder="Username" name="username" class="form-control <?= ($validation->hasError('username')) ? 'is-invalid' : '' ?>" required />
    <div class="invalid-feedback">
        <?= $validation->getError('username'); ?>
    </div>
</div>

<div class="mb-3">
    <label>Password (Kosongkan jika tidak ingin mengubah)</label>
    <input type="hidden" value="<?= esc($user['password']) ?>" name="password_lama">
    <input type="password" placeholder="Password Baru" name="password" class="form-control <?= ($validation->hasError('password')) ? 'is-invalid' : '' ?>" />
    <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah password</small>
    <div class="invalid-feedback">
        <?= $validation->getError('password'); ?>
    </div>
</div>

<div class="mb-3">
    <label>Konfirmasi Password</label>
    <input type="password" placeholder="Konfirmasi Password Baru" name="konfirmasi_password" class="form-control <?= ($validation->hasError('konfirmasi_password')) ? 'is-invalid' : '' ?>" />
    <div class="invalid-feedback">
        <?= $validation->getError('konfirmasi_password'); ?>
    </div>
</div>

<div class="mb-3">
    <label>Role</label>
    <select name="role" class="form-control <?= ($validation->hasError('role')) ? 'is-invalid' : '' ?>" required>
        <option value="">-- Pilih Role --</option>
        <option value="Admin" <?= ($user['role'] == 'Admin') ? 'selected' : '' ?>>Admin</option>
        <option value="Dosen" <?= ($user['role'] == 'Dosen') ? 'selected' : '' ?>>Dosen</option>
        <option value="Pembimbing Akademik" <?= ($user['role'] == 'Pembimbing Akademik') ? 'selected' : '' ?>>Pembimbing Akademik</option>
        <option value="Mahasiswa" <?= ($user['role'] == 'Mahasiswa') ? 'selected' : '' ?>>Mahasiswa</option>
    </select>
    <div class="invalid-feedback">
        <?= $validation->getError('role'); ?>
    </div>
</div>

<!-- Method PUT untuk update -->
<input type="hidden" name="_method" value="PUT">