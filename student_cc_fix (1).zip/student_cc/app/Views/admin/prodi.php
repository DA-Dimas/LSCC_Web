<?= $this->extend('component/layout_admin_form'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary">
            <h4 class="mb-0 text-white">Daftar Program Studi</h4>
        </div>
        <div class="card-body">
            <button class="btn btn-primary btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#modalTambahProdi"><i class="bi bi-plus-circle"></i> Tambah Prodi</button>
            <div class="table-responsive">
                <table id="myTable" class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th>Program Studi</th>
                            <th>Kelas</th>
                            <th>Tingkat</th>
                            <th style="width: 15%;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($prodi as $p) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $p['prodi'] ?></td>
                                <td><?= $p['kelas'] ?></td>
                                <td><?= $p['tingkat'] ?></td>
                                <td>
                                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditProdi<?= $p['id'] ?>">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                    <a href="<?= base_url('admin/prodi/delete/' . $p['id']) ?>"
                                        class="btn btn-danger btn-sm tombol-hapus">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>

                            <!-- Modal Edit untuk setiap Prodi -->
                            <div class="modal fade" id="modalEditProdi<?= $p['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Program Studi</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="post" action="<?= base_url('admin/prodi/update/' . $p['id']) ?>">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="prodi" class="form-label">Program Studi</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('prodi')) ? 'is-invalid' : '' ?>"
                                                        name="prodi" value="<?= $p['prodi'] ?>" required>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('prodi'); ?>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="kelas" class="form-label">Kelas</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('kelas')) ? 'is-invalid' : '' ?>"
                                                        name="kelas" value="<?= $p['kelas'] ?>" required>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('kelas'); ?>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="tingkat" class="form-label">Tingkat</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('tingkat')) ? 'is-invalid' : '' ?>"
                                                        name="tingkat" value="<?= $p['tingkat'] ?>" required>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('tingkat'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit -->

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Prodi -->
<div class="modal fade" id="modalTambahProdi" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Program Studi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= base_url('admin/prodi/save') ?>">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="prodi" class="form-label">Program Studi</label>
                        <input type="text" class="form-control <?= ($validation->hasError('prodi')) ? 'is-invalid' : '' ?>" name="prodi" required>
                        <div class="invalid-feedback">
                            <?= $validation->getError('prodi'); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="kelas" class="form-label">Kelas</label>
                        <input type="text" class="form-control <?= ($validation->hasError('kelas')) ? 'is-invalid' : '' ?>" name="kelas" required>
                        <div class="invalid-feedback">
                            <?= $validation->getError('kelas'); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="tingkat" class="form-label">Tingkat</label>
                        <input type="text" class="form-control <?= ($validation->hasError('tingkat')) ? 'is-invalid' : '' ?>" name="tingkat" required>
                        <div class="invalid-feedback">
                            <?= $validation->getError('tingkat'); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>