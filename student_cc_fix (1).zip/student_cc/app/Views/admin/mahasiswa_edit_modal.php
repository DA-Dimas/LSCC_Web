<!-- Form Edit Mahasiswa -->
<input type="hidden" class="form-control" name="mahasiswa_id" value="<?= esc($m['id']) ?>" required>

<div class="mb-3">
    <label for="nim" class="form-label">NIM</label>
    <input type="text" class="form-control" name="nim" value="<?= esc($m['nim']) ?>" required>
</div>

<div class="mb-3">
    <label for="nama" class="form-label">Nama Mahasiswa</label>
    <input type="text" class="form-control" name="nama" value="<?= esc($m['nama']) ?>" required>
</div>

<div class="mb-3">
    <label>Program Studi</label>
    <select name="id_prodi" class="form-control" required>
        <option value="">-- Pilih Program Studi --</option>
        <?php foreach ($prodi as $p) : ?>
            <option value="<?= $p['id'] ?>" <?= $p['id'] == $m['id_prodi'] ? 'selected' : '' ?>>
                <?= esc($p['prodi']) ?> - <?= esc($p['kelas']) ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

<hr>
<h5 class="fw-bold">Edit Akun</h5>

<input type="hidden" class="form-control" name="user_id" value="<?= esc($user['id']) ?>" required>

<div class="mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control" name="username" value="<?= esc($user['username']) ?>" required>
</div>

<div class="mb-3">
    <label>Password</label>
    <input type="hidden" value="<?= esc($user['password']) ?>" name="password_lama">
    <input type="password" placeholder="Kosongkan jika tidak ingin mengubah password" name="password" class="form-control" />
    <small class="text-muted">Kosongkan jika tidak ingin mengubah password</small>
</div>

<div class="mb-3">
    <label for="konfirmasi_password" class="form-label">Konfirmasi Password</label>
    <input type="password" class="form-control" name="konfirmasi_password" placeholder="Konfirmasi Password Baru (jika mengubah)">
    <small class="text-muted">Isi hanya jika mengubah password</small>
</div>

<div class="mb-3">
    <label>Role</label>
    <input type="text" class="form-control" name="role" value="<?= esc($user['role']) ?>" readonly>
</div>

<!-- Method PUT untuk update -->
<input type="hidden" name="_method" value="PUT">