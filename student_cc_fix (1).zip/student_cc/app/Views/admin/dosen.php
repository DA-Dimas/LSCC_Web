<?= $this->extend('component/layout_admin_form'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary">
            <h4 class="mb-0 text-white">Daftar Dosen</h4>
        </div>
        <div class="card-body">
            <button class="btn btn-primary btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#modalTambahDosen"><i class="bi bi-plus-circle"></i> Tambah Dosen</button>
            <div class="table-responsive">
                <table id="myTable" class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th>NIDN</th>
                            <th>Nama Dosen</th>
                            <th>Jabatan</th>
                            <th>Foto Dosen</th>
                            <th>No WhatsApp</th>
                            <th style="width: 15%;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($dosen as $d) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= esc($d['nidn']) ?></td>
                                <td><?= esc($d['nama']) ?></td>
                                <td><?= esc($d['jabatan']) ?></td>
                                <td><?= esc($d['foto']) ?></td>
                                <td><?= esc($d['no_wa']) ?></td>
                                <td>
                                    <!-- Gunakan dosen_id untuk identifikasi yang benar -->
                                    <button class="btn btn-warning btn-sm" onclick="showEditModal(<?= $d['id'] ?>)">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                    <a href="<?= base_url('admin/dosen/delete/' . $d['id']) ?>"
                                        class="btn btn-danger btn-sm tombol-hapus">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Modal Edit Dosen (Satu modal untuk semua) -->
                <div class="modal fade" id="modalEditDosen" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Dosen</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <form method="post" id="editForm" enctype="multipart/form-data">
                                <?= csrf_field(); ?>
                                <div class="modal-body" id="modalEditContent">
                                    <!-- Konten akan diisi via AJAX -->
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Dosen -->
<div class="modal fade" id="modalTambahDosen" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Dosen</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= base_url('admin/dosen/save') ?>" enctype="multipart/form-data">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" class="form-control" name="id" value="<?= $user; ?>" required>

                    <div class="mb-3">
                        <label for="nidn">NIDN</label>
                        <input type="text" value="<?= old('nidn') ?>" placeholder="Masukkan NIDN" name="nidn" class="form-control <?= ($validation->hasError('nidn')) ? 'is-invalid' : '' ?>" />
                        <div class="invalid-feedback">
                            <?= $validation->getError('nidn'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="nama">Nama Dosen</label>
                        <input type="text" value="<?= old('nama') ?>" placeholder="Masukkan Nama Lengkap" name="nama" class="form-control <?= ($validation->hasError('nama')) ? 'is-invalid' : '' ?>" />
                        <div class="invalid-feedback">
                            <?= $validation->getError('nama'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="nama">Jabatan</label>
                        <input type="text" value="<?= old('jabatan') ?>" placeholder="Masukkan Jabatan" name="jabatan" class="form-control <?= ($validation->hasError('jabatan')) ? 'is-invalid' : '' ?>" />
                        <div class="invalid-feedback">
                            <?= $validation->getError('jabatan'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="foto">Foto Dosen</label>
                        <input type="file" name="foto" class="form-control <?= ($validation->hasError('foto')) ? 'is-invalid' : '' ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('foto'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="no_wa">Nomor Whatsapp</label>
                        <input type="text" value="<?= old('no_wa') ?>" placeholder="Cth : 628xxxxxxxx" name="no_wa" class="form-control <?= ($validation->hasError('no_wa')) ? 'is-invalid' : '' ?>" />
                        <div class="invalid-feedback">
                            <?= $validation->getError('no_wa'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="instagram">Instagram</label>
                        <input type="text" value="<?= old('instagram') ?>" placeholder="Masukkan Instagram" name="instagram" class="form-control <?= ($validation->hasError('instagram')) ? 'is-invalid' : '' ?>" />
                        <div class="invalid-feedback">
                            <?= $validation->getError('instagram'); ?>
                        </div>
                    </div>

                    <hr>
                    <h5 class="fw-bold">Buat Akun</h5>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" placeholder="Masukkan Username" required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" placeholder="Masukkan Password" required>
                    </div>

                    <div class="mb-3">
                        <label for="konfirmasi_password" class="form-label">Konfirmasi Password</label>
                        <input type="password" class="form-control" name="konfirmasi_password" placeholder="Konfirmasi Password" required>
                    </div>

                    <div class="mb-3">
                        <label>Role</label>
                        <input type="text" class="form-control" name="role" value="Dosen" readonly>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function showEditModal(dosen_id) {
        // Ambil data via AJAX dengan ID dosen
        $.get('<?= base_url('admin/dosen/edit/') ?>' + dosen_id, function(data) {
            $('#modalEditContent').html(data);
            // Set action form untuk update dengan ID dosen
            $('#editForm').attr('action', '<?= base_url('admin/dosen/update/') ?>' + dosen_id);
            $('#modalEditDosen').modal('show');
        }).fail(function() {
            alert('Error: Tidak dapat memuat data dosen');
        });
    }
</script>

<?= $this->endSection(); ?>