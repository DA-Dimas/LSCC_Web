<?= $this->extend('component/layout_admin_form'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            Daftar Konsultasi

            <form method="get" class="mb-4 mt-4">
                <div class="row">
                    <div class="col-md-3">
                        <label for="filter_tahun">Tahun</label>
                        <select name="filter_tahun" class="form-control">
                            <option value="">Pilih Tahun</option>
                            <?php foreach ($tahun_list as $tahun): ?>
                                <option value="<?= $tahun ?>" <?= ($tahun == $filter_tahun) ? 'selected' : '' ?>>
                                    <?= $tahun ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="filter_bulan_awal">Bulan Awal</label>
                        <select name="filter_bulan_awal" class="form-control">
                            <option value="">Pilih Bulan Awal</option>
                            <?php
                            $nama_bulan = [
                                1 => 'Januari',
                                2 => 'Februari',
                                3 => 'Maret',
                                4 => 'April',
                                5 => 'Mei',
                                6 => 'Juni',
                                7 => 'Juli',
                                8 => 'Agustus',
                                9 => 'September',
                                10 => 'Oktober',
                                11 => 'November',
                                12 => 'Desember'
                            ];
                            for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= ($i == $filter_bulan_awal) ? 'selected' : '' ?>>
                                    <?= $nama_bulan[$i] ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="filter_bulan_akhir">Bulan Akhir</label>
                        <select name="filter_bulan_akhir" class="form-control">
                            <option value="">Pilih Bulan Akhir</option>
                            <?php
                            $nama_bulan = [
                                1 => 'Januari',
                                2 => 'Februari',
                                3 => 'Maret',
                                4 => 'April',
                                5 => 'Mei',
                                6 => 'Juni',
                                7 => 'Juli',
                                8 => 'Agustus',
                                9 => 'September',
                                10 => 'Oktober',
                                11 => 'November',
                                12 => 'Desember'
                            ];
                            for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= ($i == $filter_bulan_akhir) ? 'selected' : '' ?>>
                                    <?= $nama_bulan[$i] ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>&nbsp;</label>
                        <div>
                            <button type="submit" class="btn btn-success">Filter</button>
                            <a href="<?= base_url('admin/laporan_konsultasi') ?>" class="btn btn-secondary">Reset</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-body">
            <table id="myTable" class="table table-bordered table-striped">
                <thead class="table-dark text-center">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Mahasiswa</th>
                        <th>Keluhan</th>
                        <th>Solusi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($konsultasi)) : ?>
                        <?php
                        $no = 1;
                        $ada_data = false; // penanda untuk cek apakah ada yang ditampilkan
                        foreach ($konsultasi as $row) :
                            if (!empty($row['catatan']) && !empty($row['solusi'])) :
                                $ada_data = true;
                        ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_konsultasi'])); ?></td>
                                    <td><?= esc($row['nama_mahasiswa']); ?></td>
                                    <td><?= esc($row['catatan']); ?></td>
                                    <td><?= esc($row['solusi']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#detailModal"
                                            data-tanggal="<?= date('d/m/Y', strtotime($row['tanggal_konsultasi'])); ?>"
                                            data-mahasiswa="<?= esc($row['nama_mahasiswa']); ?>"
                                            data-dosen="<?= esc($row['nama_dosen']); ?>"
                                            data-kategori="<?= esc($row['kategori']); ?>"
                                            data-catatan="<?= esc($row['catatan']); ?>"
                                            data-solusi="<?= esc($row['solusi']); ?>"
                                            data-tindaklanjut="<?= !empty($row['tindak_lanjut']) ? esc($row['tindak_lanjut']) : 'Tidak ada tindak lanjut'; ?>">
                                            Detail
                                        </button>
                                    </td>
                                </tr>
                        <?php
                            endif;
                        endforeach;
                        ?>

                        <?php if (!$ada_data) : ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada data konsultasi</td>
                            </tr>
                        <?php endif; ?>

                    <?php else : ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data konsultasi</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>

            <div class="card mt-4">
                <div class="card-header bg-primary text-white">Grafik Konsultasi Per Bulan</div>
                <div class="card-body">
                    <canvas id="chartKonsultasi"></canvas>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header bg-primary text-white">Grafik Konsultasi Per Kategori</div>
                <div class="card-body">
                    <canvas id="chartKategori" width="100" height="100"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Detail Konsultasi -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="detailModalLabel">Detail Konsultasi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Tanggal Konsultasi</th>
                        <td id="modalTanggal"></td>
                    </tr>
                    <tr>
                        <th>Nama Mahasiswa</th>
                        <td id="modalMahasiswa"></td>
                    </tr>
                    <tr>
                        <th>Dosen</th>
                        <td id="modalDosen"></td>
                    </tr>
                    <tr>
                        <th>Kategori Keluhan</th>
                        <td id="modalKategori"></td>
                    </tr>
                    <tr>
                        <th>Catatan</th>
                        <td id="modalCatatan"></td>
                    </tr>
                    <tr>
                        <th>Solusi</th>
                        <td id="modalSolusi"></td>
                    </tr>
                    <tr>
                        <th>Tindak Lanjut</th>
                        <td id="modalTindaklanjut"></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
<script>
    var detailModal = document.getElementById('detailModal');
    detailModal.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        var tanggal = button.getAttribute('data-tanggal');
        var mahasiswa = button.getAttribute('data-mahasiswa');
        var dosen = button.getAttribute('data-dosen');
        var kategori = button.getAttribute('data-kategori');
        var catatan = button.getAttribute('data-catatan');
        var solusi = button.getAttribute('data-solusi');
        var tindaklanjut = button.getAttribute('data-tindaklanjut');

        document.getElementById('modalTanggal').textContent = tanggal;
        document.getElementById('modalMahasiswa').textContent = mahasiswa;
        document.getElementById('modalDosen').textContent = dosen;
        document.getElementById('modalKategori').textContent = kategori;
        document.getElementById('modalCatatan').textContent = catatan;
        document.getElementById('modalSolusi').textContent = solusi;
        document.getElementById('modalTindaklanjut').textContent = tindaklanjut;
    });

    // Chart Tanggal
    document.addEventListener("DOMContentLoaded", function() {
        var ctx = document.getElementById("chartKonsultasi").getContext("2d");
        var konsultasiData = <?= json_encode($konsultasi) ?>;
        var dataCounts = {};

        // Mengelompokkan data berdasarkan bulan dalam format 'YYYY-MM'
        konsultasiData.forEach(konsul => {
            var dateObj = new Date(konsul.tanggal_konsultasi);
            var bulanKey = dateObj.getFullYear() + '-' + String(dateObj.getMonth() + 1).padStart(2, '0'); // YYYY-MM
            dataCounts[bulanKey] = (dataCounts[bulanKey] || 0) + 1;
        });

        // Urutkan berdasarkan kunci (YYYY-MM)
        var sortedKeys = Object.keys(dataCounts).sort();

        // Konversi kembali ke format 'Bulan Tahun'
        var labels = sortedKeys.map(key => {
            var [year, month] = key.split('-');
            return new Date(year, month - 1).toLocaleString('id-ID', {
                month: 'long',
                year: 'numeric'
            });
        });

        var dataset = sortedKeys.map(key => dataCounts[key]);

        var chart = new Chart(ctx, {
            type: "line",
            data: {
                labels: labels,
                datasets: [{
                    label: "Jumlah Konsultasi",
                    data: dataset,
                    backgroundColor: "rgba(54, 162, 235, 0.2)",
                    borderColor: "rgba(54, 162, 235, 1)",
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });

    // Chart Kategori
    document.addEventListener("DOMContentLoaded", function() {
        var ctx = document.getElementById("chartKategori").getContext("2d");
        var konsultasiData = <?= json_encode($konsultasi) ?>;
        var dataCounts = {};

        // Mengelompokkan data berdasarkan kategori
        konsultasiData.forEach(konsul => {
            var kategori = konsul.kategori || "Tidak Diketahui";
            dataCounts[kategori] = (dataCounts[kategori] || 0) + 1;
        });

        var labels = Object.keys(dataCounts);
        var dataset = labels.map(kategori => dataCounts[kategori]);
        var totalKonsultasi = dataset.reduce((a, b) => a + b, 0);

        var chart = new Chart(ctx, {
            type: "pie",
            data: {
                labels: labels,
                datasets: [{
                    label: "Jumlah Konsultasi per Kategori",
                    data: dataset,
                    backgroundColor: [
                        "rgba(54, 162, 235, 0.6)",
                        "rgba(255, 99, 132, 0.6)",
                        "rgba(75, 192, 192, 0.6)",
                        "rgba(255, 206, 86, 0.6)",
                        "rgba(153, 102, 255, 0.6)",
                        "rgba(255, 159, 64, 0.6)",
                        "rgba(201, 203, 207, 0.6)"
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true, // Jaga rasio aspek agar tidak terlalu besar
                aspectRatio: 1.5, // Proporsi kanvas lebih kecil
                plugins: {
                    tooltip: {
                        enabled: true
                    },
                    datalabels: {
                        anchor: "center",
                        align: "center",
                        color: "white",
                        formatter: (value, context) => {
                            let percentage = ((value / totalKonsultasi) * 100).toFixed(1);
                            return `${percentage}%`;
                        },
                        font: {
                            weight: "bold",
                            size: 14
                        }
                    }
                }
            },
            plugins: [ChartDataLabels]
        });
    });
</script>

<?= $this->endSection(); ?>