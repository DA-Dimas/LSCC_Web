<?= $this->extend('component/layout_admin_form'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary">
            <h4 class="mb-0 text-white">Daftar User</h4>
        </div>
        <div class="card-body">
            <button class="btn btn-primary btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#modalTambahUser"><i class="bi bi-plus-circle"></i> Tambah User</button>
            <div class="table-responsive">
                <table id="myTable" class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th style="width: 15%;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($user as $u) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= esc($u['username']) ?></td>
                                <td><?= esc($u['role']) ?></td>
                                <td>
                                    <button class="btn btn-warning btn-sm" onclick="showEditModal(<?= $u['id'] ?>)">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                    <a href="<?= base_url('admin/user/delete/' . $u['id']) ?>"
                                        class="btn btn-danger btn-sm tombol-hapus">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit User -->
<div class="modal fade" id="modalEditUser" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" id="editForm">
                <?= csrf_field(); ?>
                <div class="modal-body" id="modalEditContent">
                    <!-- Konten akan diisi via AJAX -->
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Tambah User -->
<div class="modal fade" id="modalTambahUser" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= base_url('admin/user/save') ?>">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $user_id; ?>">
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" placeholder="Username" name="username" class="form-control <?= ($validation->hasError('username')) ? 'is-invalid' : '' ?>" required />
                        <div class="invalid-feedback">
                            <?= $validation->getError('username'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" placeholder="Password" name="password" class="form-control <?= ($validation->hasError('password')) ? 'is-invalid' : '' ?>" required />
                        <div class="invalid-feedback">
                            <?= $validation->getError('password'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Konfirmasi Password</label>
                        <input type="password" placeholder="Konfirmasi Password" name="konfirmasi_password" class="form-control <?= ($validation->hasError('konfirmasi_password')) ? 'is-invalid' : '' ?>" required />
                        <div class="invalid-feedback">
                            <?= $validation->getError('konfirmasi_password'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Role</label>
                        <select name="role" class="form-control">
                            <option value="">-- Pilih Role --</option>
                            <?php foreach (["Admin", "Dosen", "Pembimbing Akademik", "Mahasiswa"] as $option) : ?>
                                <option value="<?= $option; ?>">
                                    <?= $option; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function showEditModal(id) {
        // Ambil data via AJAX dengan ID user
        $.get('<?= base_url('admin/user/edit/') ?>' + id, function(data) {
            $('#modalEditContent').html(data);
            // Set action form untuk update dengan ID user
            $('#editForm').attr('action', '<?= base_url('admin/user/update/') ?>' + id);
            $('#modalEditUser').modal('show');
        }).fail(function(xhr, status, error) {
            console.error('Error:', error);
            alert('Error: Tidak dapat memuat data user');
        });
    }
</script>

<?= $this->endSection(); ?>