<?= $this->extend('component/layout_admin_form'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary">
            <h4 class="mb-0 text-white">Daftar Mahasiswa</h4>
        </div>
        <div class="card-body">
            <button class="btn btn-primary btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#modalTambahMahasiswa"><i class="bi bi-plus-circle"></i> Tambah Mahasiswa</button>
            <div class="table-responsive">
                <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Prodi</th>
                            <th>Kelas</th>
                            <th>Tingkat</th>
                            <th style="width: 15%;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($mahasiswa as $m) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $m['nim'] ?></td>
                                <td><?= $m['nama'] ?></td>
                                <td><?= $m['nama_prodi'] ?></td>
                                <td><?= $m['kelas'] ?></td>
                                <td><?= $m['tingkat'] ?></td>
                                <td>
                                    <!-- Gunakan mahasiswa_id untuk identifikasi yang benar -->
                                    <button class="btn btn-warning btn-sm" onclick="showEditModal(<?= $m['mahasiswa_id'] ?>)">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                    <a href="<?= base_url('admin/mahasiswa/delete/' . $m['mahasiswa_id']) ?>"
                                        class="btn btn-danger btn-sm tombol-hapus">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Modal Edit Mahasiswa (Satu modal untuk semua) -->
                <div class="modal fade" id="modalEditMahasiswa" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Mahasiswa</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <form method="post" id="editForm">
                                <?= csrf_field(); ?>
                                <div class="modal-body" id="modalEditContent">
                                    <!-- Konten akan diisi via AJAX -->
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Mahasiswa -->
<div class="modal fade" id="modalTambahMahasiswa" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= base_url('admin/mahasiswa/save') ?>">
                <?= csrf_field(); ?>
                <div class="modal-body">

                    <input type="hidden" class="form-control" name="id" value="<?= $user; ?>" required>

                    <div class="mb-3">
                        <label for="nim" class="form-label">NIM</label>
                        <input type="text" class="form-control" name="nim" placeholder="Masukkan NIM" required>
                    </div>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Mahasiswa</label>
                        <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama" required>
                    </div>

                    <div class="mb-3">
                        <label>Program Studi</label>
                        <select name="id_prodi" class="form-control">
                            <option value="">-- Pilih Program Studi --</option>
                            <?php foreach ($ambil_prodi as $p) : ?>
                                <option value="<?= $p['id']; ?>">
                                    <?= $p['prodi']; ?> - <?= $p['kelas']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <hr>
                    <h5 class="fw-bold">Buat Akun</h5>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" placeholder="Masukkan Username" required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" placeholder="Masukkan Password" required>
                    </div>

                    <div class="mb-3">
                        <label for="konfirmasi_password" class="form-label">Konfirmasi Password</label>
                        <input type="password" class="form-control" name="konfirmasi_password" placeholder="Konfirmasi Password" required>
                    </div>

                    <div class="mb-3">
                        <label>Role</label>
                        <input type="text" class="form-control" name="role" value="Mahasiswa" readonly>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function showEditModal(mahasiswa_id) {
        // Ambil data via AJAX dengan ID mahasiswa
        $.get('<?= base_url('admin/mahasiswa/edit/') ?>' + mahasiswa_id, function(data) {
            $('#modalEditContent').html(data);
            // Set action form untuk update dengan ID mahasiswa
            $('#editForm').attr('action', '<?= base_url('admin/mahasiswa/update/') ?>' + mahasiswa_id);
            $('#modalEditMahasiswa').modal('show');
        }).fail(function() {
            alert('Error: Tidak dapat memuat data mahasiswa');
        });
    }
</script>

<?= $this->endSection(); ?>