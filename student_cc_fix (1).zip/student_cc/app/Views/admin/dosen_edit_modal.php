<!-- Form Edit Dosen -->
<input type="hidden" class="form-control" name="dosen_id" value="<?= esc($d['id']) ?>" required>

<div class="mb-3">
    <label for="nidn" class="form-label">NIDN</label>
    <input type="text" class="form-control <?= ($validation->hasError('nidn')) ? 'is-invalid' : ''  ?>" name="nidn" value="<?= esc($d['nidn']) ?>" required>
    <div class="invalid-feedback">
        <?= $validation->getError('nidn'); ?>
    </div>
</div>

<div class="mb-3">
    <label for="nama" class="form-label">Nama Dosen</label>
    <input type="text" class="form-control <?= ($validation->hasError('nama')) ? 'is-invalid' : ''  ?>" name="nama" value="<?= esc($d['nama']) ?>" required>
    <div class="invalid-feedback">
        <?= $validation->getError('nama'); ?>
    </div>
</div>

<div class="mb-3">
    <label for="jabatan" class="form-label">Jabatan</label>
    <input type="text" class="form-control <?= ($validation->hasError('jabatan')) ? 'is-invalid' : ''  ?>" name="jabatan" value="<?= esc($d['jabatan']) ?>" required>
    <div class="invalid-feedback">
        <?= $validation->getError('jabatan'); ?>
    </div>
</div>

<div class="mb-3">
    <label for="foto" class="form-label">Foto Dosen</label>
    <input type="hidden" value="<?= $d['foto'] ?>" name="foto_lama">
    <input type="file" name="foto" accept=".png,.jpg,.jpeg" class="form-control <?= ($validation->hasError('foto')) ? 'is-invalid' : ''  ?>">
    <div class="invalid-feedback">
        <?= $validation->getError('foto'); ?>
    </div>
    <?php if ($d['foto']): ?>
        <small class="text-muted">Foto saat ini: <?= esc($d['foto']) ?></small>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label for="no_wa" class="form-label">Nomor Whatsapp</label>
    <input type="text" class="form-control <?= ($validation->hasError('no_wa')) ? 'is-invalid' : '' ?>" name="no_wa" value="<?= esc($d['no_wa']) ?>" required>
    <div class="invalid-feedback">
        <?= $validation->getError('no_wa'); ?>
    </div>
</div>

<div class="mb-3">
    <label for="instagram" class="form-label">Instagram</label>
    <input type="text" class="form-control" name="instagram" value="<?= esc($d['instagram']) ?>">
</div>

<hr>
<h5 class="fw-bold">Edit Akun</h5>

<input type="hidden" class="form-control" name="user_id" value="<?= esc($user['id']) ?>" required>

<div class="mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control" name="username" value="<?= esc($user['username']) ?>" required>
</div>

<div class="mb-3">
    <label>Password</label>
    <input type="hidden" value="<?= esc($user['password']) ?>" name="password_lama">
    <input type="password" placeholder="Kosongkan jika tidak ingin mengubah password" name="password" class="form-control" />
    <small class="text-muted">Kosongkan jika tidak ingin mengubah password</small>
</div>

<div class="mb-3">
    <label for="konfirmasi_password" class="form-label">Konfirmasi Password</label>
    <input type="password" class="form-control" name="konfirmasi_password" placeholder="Konfirmasi Password Baru (jika mengubah)">
    <small class="text-muted">Isi hanya jika mengubah password</small>
</div>

<div class="mb-3">
    <label>Role</label>
    <input type="text" class="form-control" name="role" value="<?= esc($user['role']) ?>" readonly>
</div>

<!-- Method PUT untuk update -->
<input type="hidden" name="_method" value="PUT">