<?= $this->extend('component/layout_mahasiswa'); ?>
<?= $this->section('content'); ?>

<div class="container mt-5" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            Form Janji Temu
        </div>
        <div class="card-body">

            <?php if (session()->getFlashdata('errors')): ?>
                <div class="alert alert-danger">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <p><?= $error ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>


            <form method="post" action="<?= base_url('janji_temu') ?>">
                <?= csrf_field(); ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="id_prodi" class="form-label">Pilih Prodi</label>
                            <select class="form-select" id="id_prodi" name="id_prodi" required>
                                <option disabled <?= empty($selected_prodi) ? 'selected' : '' ?>>Pilih Prodi</option>
                                <?php foreach ($prodi as $p): ?>
                                    <option value="<?= $p['id_prodi']; ?>" <?= ($selected_prodi == $p['id_prodi']) ? 'selected' : '' ?>>
                                        <?= $p['prodi']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="tingkat" class="form-label">Pilih Tingkat</label>
                            <select class="form-select" id="tingkat" name="tingkat" required>
                                <option disabled <?= empty($selected_tingkat) ? 'selected' : '' ?>>Pilih Tingkat</option>
                                <option value="Tingkat 1" <?= ($selected_tingkat == 'Tingkat 1') ? 'selected' : '' ?>>Tingkat 1</option>
                                <option value="Tingkat 2" <?= ($selected_tingkat == 'Tingkat 2') ? 'selected' : '' ?>>Tingkat 2</option>
                                <option value="Tingkat 3" <?= ($selected_tingkat == 'Tingkat 3') ? 'selected' : '' ?>>Tingkat 3</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Filter Mahasiswa</button>
                </div>
            </form>


            <form method="post" action="<?= base_url('janji_temu/save'); ?>">
                <?= csrf_field(); ?>
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="id_mahasiswa" class="form-label">Nama Mahasiswa</label>
                            <select class="form-select" id="id_mahasiswa" name="id_mahasiswa" required>
                                <option selected disabled>Pilih Mahasiswa</option>
                                <?php foreach ($mahasiswa as $m): ?>
                                    <option value="<?= $m['id']; ?>"><?= $m['nama']; ?> (<?= $m['nim']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="id_dosen" class="form-label">Nama Dosen</label>
                            <select class="form-select" id="id_dosen" name="id_dosen" required>
                                <option selected disabled>Pilih Dosen</option>
                                <?php foreach ($dosen as $d): ?>
                                    <option value="<?= $d['id']; ?>"><?= $d['nama']; ?> (<?= $d['nidn']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="id_kategori" class="form-label">Nama Kategori</label>
                            <select class="form-select" id="id_kategori" name="id_kategori" required>
                                <option selected disabled>Pilih Kategori</option>
                                <?php foreach ($kategori as $k): ?>
                                    <option value="<?= $k['id']; ?>"><?= $k['kategori']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="tanggal" class="form-label">Tanggal Janji Temu</label>
                            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="jam_mulai" class="form-label">Jam Mulai</label>
                            <input type="time" class="form-control" id="jam_mulai" name="jam_mulai" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="jam_selesai" class="form-label">Jam Selesai</label>
                            <input type="time" class="form-control" id="jam_selesai" name="jam_selesai" required>
                        </div>
                    </div>
                    <div class="mt-2">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                        <button type="reset" class="btn btn-secondary"><i class="bi bi-arrow-clockwise"></i> Reset</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection();  ?>