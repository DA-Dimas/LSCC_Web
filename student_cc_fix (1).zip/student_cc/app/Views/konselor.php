<?= $this->extend('component/layout_mahasiswa'); ?>
<?= $this->section('content'); ?>

<section id="trainers" class="section trainers">

  <div class="container">

    <div class="row gy-5">

      <h2>Konselor</h2>
      <?php foreach ($dosen as $d) : ?>
        <div class="col-lg-4 col-md-6 member" data-aos="fade-up" data-aos-delay="100">
          <div class="member-img">
          <img src="<?= base_url('assets/img/profile_dosen/' . (!empty($d['foto']) ? $d['foto'] : 'user.jpg')) ?>" 
          class="img-fluid rounded-circle shadow-sm" 
          alt="Foto Dosen" 
          style="width: 200px; height: 200px; object-fit: cover; border: 3px solid #fff;">
            <div class="social">
              <a href="https://wa.me/<?= $d['no_wa'] ?>" target="_blank"><i class="bi bi-whatsapp"></i></a>
              <a href="https://www.instagram.com/<?= $d['instagram'] ?>" target="_blank"><i class="bi bi-instagram"></i></a>
            </div>
          </div>
          <div class="member-info text-center">
            <h4><?= $d['nidn'] ?></h4>
            <span><?= $d['nama'] ?></span>
          </div>
        </div><!-- End Team Member -->
      <?php endforeach; ?>

    </div>

  </div>

</section><!-- /Trainers Section -->

<?= $this->endSection();  ?>