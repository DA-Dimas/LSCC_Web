<?= $this->extend('component/layout_mahasiswa_jt'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            Daftar Janji Temu
        </div>
        <div class="card-body">
            <table id="tabelJanjiTemu" class="table table-bordered table-striped">
                <thead class="table-dark text-center">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Mahasiswa</th>
                        <th>Nama Dosen</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($janji_temu)) : ?>
                        <?php $no = 1;
                        foreach ($janji_temu as $row) : ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= date('d/m/Y', strtotime($row['tanggal_konsultasi'])); ?></td>
                                <td><?= esc($row['nama_mahasiswa']); ?></td>
                                <td><?= esc($row['nama_dosen']); ?></td>
                                <td class="text-center">
                                    <?php
                                    $status = strtolower($row['status']);
                                    $badge = 'secondary'; // default abu-abu
                                    $label = ucfirst($status); // biar huruf besar depan

                                    switch ($status) {
                                        case 'disetujui_dosen':
                                            $badge = 'warning'; // hijau
                                            break;
                                        case 'ditolak_dosen':
                                            $badge = 'danger'; // merah
                                            break;
                                        case 'disetujui_admin':
                                            $badge = 'success'; // hijau
                                            break;
                                        case 'ditolak_admin':
                                            $badge = 'danger'; // merah
                                            break;
                                        case 'selesai':
                                            $badge = 'primary'; // biru
                                            break;
                                        case 'dibatalkan':
                                            $badge = 'danger'; // biru
                                            break;
                                        case 'pending':
                                        default:
                                            $badge = 'secondary'; // abu-abu
                                            break;
                                    }
                                    ?>
                                    <span class="badge bg-<?= $badge; ?>"><?= $label; ?></span>
                                </td>
                                <td><?= !empty($row['keterangan']) ? esc($row['keterangan']) : 'Belum ada keterangan'; ?></td>
                                <td>
                                    <?php if (!in_array(strtolower($row['status']), ['ditolak_dosen', 'ditolak_admin','selesai', 'dibatalkan'])) : ?>
                                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditJanjiTemu<?= $row['id'] ?>">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </button>
                                        <?php else : ?>
                                            <button class="btn btn-warning btn-sm" disabled>
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <!-- Modal Edit untuk setiap Prodi -->
                            <div class="modal fade" id="modalEditJanjiTemu<?= $row['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Janji Temu</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="post" action="<?= base_url('mahasiswa/laporan_janji_temu/update/' . $row['id']) ?>">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="status" class="form-label">Status</label>
                                                    <select name="status" class="form-control">
                                                        <option value="dibatalkan" <?= $row['status'] == 'dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('janji_temu'); ?>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="keterangan" class="form-label">Keterangan</label>
                                                    <textarea name="keterangan" id="keterangan" class="form-control"><?= esc($row['keterangan']) ?></textarea>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('keterangan'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit -->
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data konsultasi</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>