<?= $this->extend('component/layout_mahasiswa_jt'); ?>
<?= $this->section('content'); ?>

<div class="container mt-5" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            Form Janji Temu
        </div>
        <div class="card-body">

            <?php if (session()->getFlashdata('errors')): ?>
                <div class="alert alert-danger">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <p><?= $error ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="<?= base_url('mahasiswa/janji_temu/save'); ?>">
                <?= csrf_field(); ?>
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="id_mahasiswa" class="form-label">Nama Mahasiswa</label>
                            <select class="form-select <?= ($validation->hasError('id_mahasiswa')) ? 'is-invalid' : '' ?>" id="id_mahasiswa" name="id_mahasiswa">
                                <?php foreach ($mahasiswa as $m): ?>
                                    <option value="<?= $m['id']; ?>"><?= $m['nama']; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">
                                <?= $validation->getError('id_mahasiswa'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="id_dosen" class="form-label">Nama Dosen</label>
                            <select class="form-select <?= ($validation->hasError('id_dosen')) ? 'is-invalid' : '' ?>" id="id_dosen" name="id_dosen">
                                <option selected disabled>Pilih Dosen</option>
                                <?php if (!empty($dosen)) : ?>
                                    <?php foreach ($dosen as $d) : ?>
                                        <option value="<?= $d['id']; ?>">
                                            <?= $d['nama']; ?> (<?= $d['nidn']; ?>)
                                        </option>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <option disabled>-- Tidak ada dosen tersedia --</option>
                                <?php endif; ?>
                            </select>
                            <div class="invalid-feedback">
                                <?= $validation->getError('id_dosen'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="id_kategori" class="form-label">Nama Kategori</label>
                            <select class="form-select <?= ($validation->hasError('id_kategori')) ? 'is-invalid' : '' ?>" id="id_kategori" name="id_kategori">
                                <option selected disabled>Pilih Kategori</option>
                                <?php foreach ($kategori as $k): ?>
                                    <option value="<?= $k['id']; ?>"><?= $k['kategori']; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">
                                <?= $validation->getError('id_kategori'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="tanggal" class="form-label">Tanggal Janji Temu</label>
                            <input type="date" class="form-control <?= ($validation->hasError('tanggal_konsultasi')) ? 'is-invalid' : '' ?>" id="tanggal" name="tanggal_konsultasi">
                            <div class="invalid-feedback">
                                <?= $validation->getError('tanggal_konsultasi'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="jam_mulai" class="form-label">Jam Mulai</label>
                            <input type="time" class="form-control <?= ($validation->hasError('jam_mulai')) ? 'is-invalid' : '' ?>" id="jam_mulai" name="jam_mulai">
                            <div class="invalid-feedback">
                                <?= $validation->getError('jam_mulai'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="jam_selesai" class="form-label">Jam Selesai</label>
                            <input type="time" class="form-control <?= ($validation->hasError('id_mahasiswa')) ? 'is-invalid' : '' ?>" id="jam_selesai" name="jam_selesai">
                            <div class="invalid-feedback">
                                <?= $validation->getError('jam_selesai'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                        <a href="<?= base_url('mahasiswa/janji_temu') ?>" class="btn btn-secondary">Reset</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection();  ?>