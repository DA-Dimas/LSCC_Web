<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title><?= $title ?> - LSCC</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="<?= base_url('assets/img/lscc.png') ?>" rel="icon">
  <link href="<?= base_url('assets/img/apple-touch-icon.png') ?>" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/bootstrap-icons/bootstrap-icons.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/aos/aos.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/glightbox/css/glightbox.min.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/swiper/swiper-bundle.min.css') ?>" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="<?= base_url('assets/css/main.css') ?>" rel="stylesheet">

  <!-- LineIcons -->
  <link rel="stylesheet" href="https://cdn.lineicons.com/5.0/lineicons.css" />

  <!-- Datatables -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="" class="logo d-flex align-items-center me-auto">
        <!-- <h1 class="sitename text-primary">LP3I SCC</h1> -->
        <img src="<?= base_url('assets/img/lscc.png'); ?>" alt="Logo LSCC" style="max-height: 80px; width: auto;">
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?= base_url('dosen/dashboard') ?>" class="<?= uri_string() == 'dosen/dashboard' ? 'active' : '' ?>">Home</a></li>
          <li><a href="<?= base_url('dosen/janji_temu') ?>" class="<?= uri_string() == 'dosen/janji_temu' ? 'active' : '' ?>">Janji Temu
            <?php if ($notif > 0): ?>
              <span class="badge bg-danger rounded-pill ms-1"><?= $notif ?></span>
            <?php endif; ?>
          </a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      <?php if (session()->get('logged_in')) : ?>
        <a class="btn-getstarted" style="border-radius:20px" href="<?= base_url('/logout') ?>">Logout</a>
      <?php else : ?>
        <a class="btn-getstarted" href="<?= base_url('/login') ?>">Login</a>
      <?php endif; ?>
    </div>
  </header>

  <?php if (session()->getFlashdata('success')) : ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
      const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.onmouseenter = Swal.stopTimer;
          toast.onmouseleave = Swal.resumeTimer;
        }
      });
      Toast.fire({
        icon: "success",
        title: "<?= $_SESSION['success'] ?>"
      });
    </script>
  <?php endif; ?>


  <main class="main">

    <?= $this->renderSection('content'); ?>

  </main>

  <footer data-aos="fade-up" data-aos-delay="100" style="background-color: #f8f9fa; color: #343a40; padding: 16px 0; margin-top: 32px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
    <div style="text-align: center;">
      <p style="margin-bottom: 4px; font-weight: bold;">© 2025 LP3I Student Care Center | Politeknik LP3I Jakarta Kampus Depok</p>
      <p style="margin-bottom: 4px; color: #6c757d;">Jl. Raya Bogor KM38 No.56, Sukamaju, Kec. Cilodong, Kota Depok, Jawa Barat 16415</p>
      <p>
        <a href="#" style="color: #343a40; margin-right: 12px; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-facebook"></i>
        </a>
        <a href="#" style="color: #343a40; margin-right: 12px; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-twitter"></i>
        </a>
        <a href="#" style="color: #343a40; margin-right: 12px; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-instagram"></i>
        </a>
        <a href="#" style="color: #343a40; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-linkedin"></i>
        </a>
      </p>
    </div>
  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/php-email-form/validate.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/aos/aos.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/glightbox/js/glightbox.min.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/purecounter/purecounter_vanilla.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/swiper/swiper-bundle.min.js') ?>"></script>

  <!-- Main JS File -->
  <script src="<?= base_url('assets/js/main.js') ?>"></script>

  <!-- jQuery (wajib untuk DataTables) -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

  <!-- DataTables JS -->
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

  <!-- Inisialisasi DataTable -->
  <script>
    $(document).ready(function() {
      $('#tabelJanjiTemu').DataTable({
        responsive: true,
        language: {
          url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json" // Bahasa Indonesia
        }
      });
    });
  </script>


</body>

</html>