<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title><?= $title ?> - LSCC</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="<?= base_url('assets/img/lscc.png') ?>" rel="icon">
  <link href="<?= base_url('assets/img/apple-touch-icon.png') ?>" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/bootstrap-icons/bootstrap-icons.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/aos/aos.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/glightbox/css/glightbox.min.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/swiper/swiper-bundle.min.css') ?>" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="<?= base_url('assets/css/main.css') ?>" rel="stylesheet">

  <!-- LineIcons -->
  <link rel="stylesheet" href="https://cdn.lineicons.com/5.0/lineicons.css" />

  <!-- DataTables & Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap5.min.css">
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="" class="logo d-flex align-items-center me-auto">
        <!-- <h1 class="sitename text-primary">LP3I SCC</h1> -->
        <img src="<?= base_url('assets/img/lscc.png'); ?>" alt="Logo LSCC" style="max-height: 80px; width: auto;">
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?= base_url('/admin/dashboard') ?>" class="<?= uri_string() == 'admin/dashboard' ? 'active' : '' ?>">Home</a></li>
          <li class="dropdown"><a href="#"><span>Master Data</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="<?= base_url('admin/mahasiswa') ?>">Data Mahasiswa</a></li>
              <li><a href="<?= base_url('admin/dosen') ?>">Data Dosen</a></li>
              <li><a href="<?= base_url('admin/user') ?>">Data User</a></li>
              <li><a href="<?= base_url('admin/prodi') ?>">Data Prodi</a></li>
              <li><a href="<?= base_url('admin/kategori') ?>">Data Kategori Keluhan</a></li>
            </ul>
          </li>
          <li><a href="<?= base_url('admin/laporan_konsultasi') ?>" class="<?= uri_string() == 'admin/laporan_konsultasi' ? 'active' : '' ?>">Laporan Konsultasi</a></li>
          <li><a href="<?= base_url('admin/laporan_janji_temu') ?>" class="<?= uri_string() == 'admin/laporan_janji_temu' ? 'active' : '' ?>">Laporan Janji Temu
              <?php if ($notif > 0): ?>
                <span class="badge bg-danger rounded-pill ms-1"><?= $notif ?></span>
              <?php endif; ?>
            </a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      <?php if (session()->get('logged_in')) : ?>
        <a class="btn-getstarted" style="border-radius:20px" href="<?= base_url('/logout') ?>">Logout</a>
      <?php else : ?>
        <a class="btn-getstarted" href="<?= base_url('/login') ?>">Login</a>
      <?php endif; ?>
    </div>
  </header>

  <main class="main">

    <?= $this->renderSection('content'); ?>

  </main>

  <footer data-aos="fade-up" data-aos-delay="100" style="background-color: #f8f9fa; color: #343a40; padding: 16px 0; margin-top: 32px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
    <div style="text-align: center;">
      <p style="margin-bottom: 4px; font-weight: bold;">© 2025 LP3I Student Care Center | Politeknik LP3I Jakarta Kampus Depok</p>
      <p style="margin-bottom: 4px; color: #6c757d;">Jl. Raya Bogor KM38 No.56, Sukamaju, Kec. Cilodong, Kota Depok, Jawa Barat 16415</p>
      <p>
        <a href="#" style="color: #343a40; margin-right: 12px; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-facebook"></i>
        </a>
        <a href="#" style="color: #343a40; margin-right: 12px; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-twitter"></i>
        </a>
        <a href="#" style="color: #343a40; margin-right: 12px; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-instagram"></i>
        </a>
        <a href="#" style="color: #343a40; font-size: 1.5rem; transition: color 0.3s;" onmouseover="this.style.color='#0d6efd'" onmouseout="this.style.color='#343a40'">
          <i class="bi bi-linkedin"></i>
        </a>
      </p>
    </div>
  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/php-email-form/validate.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/aos/aos.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/glightbox/js/glightbox.min.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/purecounter/purecounter_vanilla.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/swiper/swiper-bundle.min.js') ?>"></script>

  <!-- Main JS File -->
  <script src="<?= base_url('assets/js/main.js') ?>"></script>

  <!-- jQuery & DataTables -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>

  <!-- SweetAlert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <?php if (session()->getFlashdata('success')) : ?>
    <script>
      const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.onmouseenter = Swal.stopTimer;
          toast.onmouseleave = Swal.resumeTimer;
        }
      });
      Toast.fire({
        icon: "success",
        title: "<?= $_SESSION['success'] ?>"
      });
    </script>
  <?php endif; ?>

  <script>
    $(document).ready(function() {
      $('#myTable').DataTable({
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "lengthMenu": [15, 30, 50, 100, 400],
        "language": {
          "search": "Cari:",
          "lengthMenu": "Tampilkan _MENU_ data",
          "info": "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
          "paginate": {
            "first": "Awal",
            "last": "Akhir",
            "next": "Berikutnya",
            "previous": "Sebelumnya"
          }
        },
        dom: '<"row"<"col-md-6"l><"col-md-6"f>>rtip<"row mt-2"<"col-md-12 text-center"B>>',
        buttons: [{
            extend: 'excelHtml5',
            text: '<i class="bi bi-file-earmark-excel"></i> Export Excel',
            className: 'btn btn-success me-2'
          },
          {
            extend: 'pdfHtml5',
            text: '<i class="bi bi-file-earmark-pdf"></i> Export PDF',
            className: 'btn btn-danger'
          }
        ]
      });
    });

    // Alert untuk data berhasil dihapus
    $('.tombol-hapus').on('click', function() {
      var getLink = $(this).attr('href');

      Swal.fire({
        title: "Yakin dihapus?",
        text: "Data yang sudah dihapus tidak bisa dikembalikan!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Ya, Saya Yakin"
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = getLink;
        }
      });
      return false;
    });
  </script>

</body>

</html>