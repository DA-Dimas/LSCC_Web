<?= $this->extend('component/layout_pa'); ?>
<?= $this->section('content'); ?>

<div class="container mt-5" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            Form Tindak Lanjut
        </div>
        <div class="card-body">
            <form action="<?= base_url('dosen/tindaklanjut/save') ?>" method="post">
            <?= csrf_field(); ?>
                <div class="mb-3">
                    <label for="id_konsultasi" class="form-label">ID Konsultasi</label>
                    <select class="form-select" id="id_konsultasi" name="id_konsultasi" required>
                        <option value="">-- Pilih Konsultasi --</option>
                        <?php foreach ($konsultasi as $row) : ?>
                            <option value="<?= $row['id'] ?>">
                                <?= $row['nama_mahasiswa']?> - <?= $row['tanggal_konsultasi'] ?> - <?= $row['kategori'] ?> 
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="tindak_lanjut" class="form-label">Tindak Lanjut</label>
                    <textarea class="form-control" id="tindak_lanjut" name="tindak_lanjut" rows="4" placeholder="Masukkan tindak lanjut..." required></textarea>
                </div>

                <div class="mb-3">
                    <label for="dibuat_oleh" class="form-label">Dibuat Oleh</label>
                    <input type="text" class="form-control" id="dibuat_oleh" name="dibuat_oleh" value="<?= session()->get('username'); ?>" readonly>
                </div>

                <div class="text-end">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>



<?= $this->endSection(); ?>