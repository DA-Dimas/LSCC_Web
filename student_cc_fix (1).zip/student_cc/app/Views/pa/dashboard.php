<?= $this->extend('component/layout_pa'); ?>
<?= $this->section('content'); ?>

<section id="about" class="about section">

  <div class="container">

    <div class="row gy-4">

      <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-up" data-aos-delay="100">
        <img src="<?= base_url('assets/img/sample-1.jpg') ?>" class="img-fluid" alt="">
      </div>

      <div class="col-lg-6 order-2 order-lg-1 content" data-aos="fade-up" data-aos-delay="200" style="text-align : justify;">
        <h3>Tentang LP3I SCC</h3>
        <p class="text-black">
          <b>LP3I Student Care Center</b> adalah pusat layanan mahasiswa yang hadir untuk memberikan dukungan akademik, emosional, dan karier bagi seluruh mahasiswa LP3I Depok. Website ini menjadi sarana utama bagi dosen dan mahasiswa untuk:
        </p>
        <ul>
          <li><i class="bi bi-stars"></i> <span>Konsultasi & Keluhan</span></li>
          <li><i class="bi bi-arrow-repeat"></i> <span>Tindak Lanjut Keluhan</span></li>
          <li><i class="bi bi-clipboard-check"></i> <span>Pelaporan</span></li>
        </ul>
        <p class="text-black">
          Bersama <b>LP3I Student Care Center</b>, LP3I berkomitmen untuk menciptakan lingkungan belajar yang nyaman, inklusif, dan mendukung perkembangan setiap mahasiswa.<i class="bi bi-heart-fill text-primary"></i><i class="bi bi-mortarboard-fill"></i>
        </p>
      </div>

    </div>

  </div>

</section><!-- /Tentang Section -->

<!-- Manfaat  Section -->
<section id="about" class="about section">

  <div class="container">

    <div class="row gy-4">

      <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
        <img src="<?= base_url('assets/img/sample-2.jpg') ?>" class="img-fluid" alt="" style="border-radius:8px;">
      </div>

      <div class="col-lg-6 order-2 order-lg-1 content" data-aos="fade-up" data-aos-delay="200" style="text-align: justify;">
        <h3>Manfaat LP3I SCC</h3>
        <p class="text-black">
          Kehadiran <b>LP3I Student Care Center</b> memberikan berbagai manfaat bagi dosen dan mahasiswa,
          khususnya dalam menangani keluhan akademik dan non-akademik. Beberapa manfaat utama dari layanan ini antara lain:
        </p>
        <ul>
          <li><i class="bi bi-chat-square-text"></i> <span>Memudahkan mahasiswa dalam menyampaikan keluhan akademik maupun non-akademik.</span></li>
          <li><i class="bi bi-person-check"></i> <span>Memberikan akses bagi dosen untuk mendokumentasikan hasil konsultasi mahasiswa.</span></li>
          <li><i class="bi bi-people"></i> <span>Meningkatkan komunikasi antara mahasiswa dan pihak akademik guna menciptakan lingkungan belajar yang lebih baik.</span></li>
          <li><i class="bi bi-lightbulb"></i> <span>Membantu mahasiswa dalam menemukan solusi terhadap permasalahan akademik dan pengembangan diri.</span></li>
        </ul>
      </div>
    </div>
  </div>

</section><!-- /About Section -->

<!-- /Visi misi Section -->
<section id="why-us" class="section why-us">

  <div class="container">

    <div class="row gy-2 justify-content-center">

      <div class="col-lg-8 d-flex align-items-stretch">
        <div class="row gy-2" data-aos="fade-up" data-aos-delay="200">

          <div class="col-xl-6">
            <div class="icon-box d-flex flex-column justify-content-center align-items-center">
              <i class="bi bi-bullseye"></i>
              <h4>Visi</h4>
              <p>Menjadi sistem informasi unggulan dalam mendukung program konsultasi akademik dan non-akademik bagi mahasiswa LP3I, guna menciptakan lingkungan belajar yang lebih responsif dan transparan, serta membantu dosen dalam memberikan bimbingan yang lebih efektif guna meningkatkan kualitas pendidikan.</p>
            </div>
          </div><!-- End Icon Box -->

          <div class="col-xl-6" data-aos="fade-up" data-aos-delay="300">
            <div class="icon-box d-flex flex-column justify-content-center align-items-center">
              <i class="bi bi-trophy"></i>
              <h4>Misi</h4>
              <p>Menyediakan platform digital yang memudahkan dosen dalam mencatat hasil konsultasi mahasiswa, meningkatkan transparansi layanan bimbingan pada mahasiswa, serta mengoptimalkan pemantauan perkembangan mahasiswa dengan sistem pencatatan dan laporan yang terstruktur untuk mendukung pengambilan keputusan berbasis data.</p>
            </div>
          </div><!-- End Icon Box -->

        </div>
      </div>

    </div>

  </div>

</section>
<!-- /Visi misi Section -->

<!-- Counts Section -->
<section id="counts" class="section counts light-background">

  <div class="container" data-aos="fade-up" data-aos-delay="100">

    <div class="row gy-4">

      <div class="col-lg-3 col-md-6">
        <div class="stats-item text-center w-100 h-100">
          <span data-purecounter-start="0" data-purecounter-end="<?= $mahasiswa ?>" data-purecounter-duration="1" class="purecounter"></span>
          <p>Mahasiswa</p>
        </div>
      </div><!-- End Stats Item -->

      <div class="col-lg-3 col-md-6">
        <div class="stats-item text-center w-100 h-100">
          <span data-purecounter-start="0" data-purecounter-end="<?= $dosen ?>" data-purecounter-duration="1" class="purecounter"></span>
          <p>Konselor</p>
        </div>
      </div><!-- End Stats Item -->

      <div class="col-lg-3 col-md-6">
        <div class="stats-item text-center w-100 h-100">
          <span data-purecounter-start="0" data-purecounter-end="<?= $konsultasi ?>" data-purecounter-duration="1" class="purecounter"></span>
          <p>Konsultasi</p>
        </div>
      </div><!-- End Stats Item -->

      <div class="col-lg-3 col-md-6">
        <div class="stats-item text-center w-100 h-100">
          <span data-purecounter-start="0" data-purecounter-end="<?= $tindaklanjut ?>" data-purecounter-duration="1" class="purecounter"></span>
          <p>TindakLanjut</p>
        </div>
      </div><!-- End Stats Item -->

    </div>

  </div>

</section><!-- /Counts Section -->

<section id="trainers-index" class="section trainers-index">

  <div class="container">

    <div class="row">

      <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="100">
        <div class="member">
          <img src="<?= base_url('assets/img/profile/dimas.png') ?>" class="img-fluid" alt="">
          <div class="member-content">
            <h4>Dimas Adhitya</h4>
            <span>Web Development</span>
            <div class="social">
              <a href="https://wa.me/6283806875311" target="_blank"><i class="bi bi-whatsapp"></i></a>
              <a href="https://www.instagram.com/dimss_ady/" target="_blank"><i class="bi bi-instagram"></i></a>
              <a href="https://www.linkedin.com/in/dimasadhitya/" target="_blank"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
        </div>
      </div><!-- End Team Member -->

      <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="200">
        <div class="member">
          <img src="<?= base_url('assets/img/profile/dimas.png') ?>" class="img-fluid" alt="">
          <div class="member-content">
            <h4>Nova Nila Nasution</h4>
            <span>Kepala Bidang Akademik</span>
            <div class="social">
              <a href="https://wa.me/6281282006079" target="_blank"><i class="bi bi-whatsapp"></i></a>
              <a href=""><i class="bi bi-instagram" target="_blank"></i></a>
              <a href=""><i class="bi bi-linkedin" target="_blank"></i></a>
            </div>
          </div>
        </div>
      </div><!-- End Team Member -->

      <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="300">
        <div class="member">
          <img src="<?= base_url('assets/img/profile/dimas.png') ?>" class="img-fluid" alt="">
          <div class="member-content">
            <h4>Anggara Setiawan</h4>
            <span>Kepala Bidang C&P</span>
            <div class="social">
              <a href="https://wa.me/6281298861965" target="_blank"><i class="bi bi-whatsapp"></i></a>
              <a href=""><i class="bi bi-instagram" target="_blank"></i></a>
              <a href=""><i class="bi bi-linkedin" target="_blank"></i></a>
            </div>
          </div>
        </div>
      </div><!-- End Team Member -->

    </div>

  </div>

</section><!-- /Trainers Index Section -->

<?= $this->endSection(); ?>