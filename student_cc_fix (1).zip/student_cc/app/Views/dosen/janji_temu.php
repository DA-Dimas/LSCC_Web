<?= $this->extend('component/layout_dosen_form'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4" data-aos="fade-up" data-aos-delay="100">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            Daftar Janji Temu
        </div>
        <div class="card-body">
            <table id="tabelJanjiTemu" class="table table-bordered table-striped">
                <thead class="table-dark text-center">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Mahasiswa</th>
                        <th>Nama Dosen</th>
                        <th>Status</th>
                        <th>aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($janji_temu)) : ?>
                        <?php $no = 1;
                        foreach ($janji_temu as $row) : ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= date('d/m/Y', strtotime($row['tanggal_konsultasi'])); ?></td>
                                <td><?= esc($row['nama_mahasiswa']); ?></td>
                                <td><?= esc($row['nama_dosen']); ?></td>
                                <td class="text-center">
                                    <?php
                                    $status = strtolower($row['status']);
                                    $badge = 'secondary'; // default abu-abu
                                    $label = ucfirst($status); // biar huruf besar depan

                                    switch ($status) {
                                        case 'disetujui_dosen':
                                            $badge = 'warning'; // hijau
                                            break;
                                        case 'ditolak_dosen':
                                            $badge = 'danger'; // merah
                                            break;
                                        case 'disetujui_admin':
                                            $badge = 'success'; // hijau
                                            break;
                                        case 'ditolak_admin':
                                            $badge = 'danger'; // merah
                                            break;
                                        case 'selesai':
                                            $badge = 'primary'; // biru
                                            break;
                                        case 'dibatalkan':
                                            $badge = 'danger'; // biru
                                            break;
                                        case 'pending':
                                        default:
                                            $badge = 'secondary'; // abu-abu
                                            break;
                                    }
                                    ?>
                                    <span class="badge bg-<?= $badge; ?>"><?= $label; ?></span>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#detailModal"
                                        data-tanggal="<?= date('d/m/Y', strtotime($row['tanggal_konsultasi'])); ?>"
                                        data-mahasiswa="<?= esc($row['nama_mahasiswa']); ?>"
                                        data-dosen="<?= esc($row['nama_dosen']); ?>"
                                        data-kategori="<?= esc($row['kategori']); ?>"
                                        data-jam_mulai="<?= esc($row['jam_mulai']); ?>"
                                        data-jam_selesai="<?= esc($row['jam_selesai']); ?>"
                                        data-status="<?= !empty($row['status']) ? esc($row['status']) : 'Proses'; ?>"
                                        data-keterangan="<?= !empty($row['keterangan']) ? esc($row['keterangan']) : 'Tidak ada keterangan'; ?>"
                                        data-updated_by="<?= !empty($row['nama_dosen']) ? esc($row['nama_dosen']) : 'Belum diupdated'; ?>">
                                        Detail
                                    </button>

                                    <?php if (in_array(strtolower($row['status']), ['ditolak_admin','selesai', 'dibatalkan'])) : ?>
                                        <button class="btn btn-warning btn-sm" disabled title="Konsultasi telah dilakukan">
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditJanjiTemu<?= $row['id'] ?>">
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </button>
                                    <?php endif; ?>

                                    <?php if (!in_array(strtolower($row['status']), ['ditolak_dosen', 'ditolak_admin','selesai', 'dibatalkan','proses','disetujui_dosen'])): ?>
                                        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalKonsultasi<?= $row['id'] ?>">
                                            <i class="bi bi-pencil-square"></i> Konsul
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-success btn-sm" disabled title="Menunggu persetujuan admin">
                                            <i class="bi bi-pencil-square"></i> Konsul
                                        </button>
                                    <?php endif; ?>

                                </td>
                            </tr>

                            <!-- Modal Edit untuk setiap Prodi -->
                            <div class="modal fade" id="modalEditJanjiTemu<?= $row['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Janji Temu</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="post" action="<?= base_url('dosen/janji_temu/update/' . $row['id']) ?>">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="status" class="form-label">Status</label>
                                                    <select name="status" class="form-control">
                                                        <option value="">-- Pilih Status --</option>
                                                        <option value="disetujui_dosen" <?= $row['status'] == 'disetujui_dosen' ? 'selected' : '' ?>>Disetujui</option>
                                                        <option value="ditolak_dosen" <?= $row['status'] == 'ditolak_dosen' ? 'selected' : '' ?>>Ditolak</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('janji_temu'); ?>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="keterangan" class="form-label">Keterangan</label>
                                                    <textarea name="keterangan" id="keterangan" class="form-control"><?= esc($row['keterangan']) ?></textarea>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('keterangan'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit -->

                            <!-- Modal Konsultasi -->
                            <div class="modal fade" id="modalKonsultasi<?= $row['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Konsultasi</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="post" action="<?= base_url('dosen/janji_temu/konsul/' . $row['id']) ?>">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="catatan" class="form-label">Catatan</label>
                                                    <textarea name="catatan" id="catatan" class="form-control"><?= esc($row['catatan']) ?></textarea>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('catatan'); ?>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="solusi" class="form-label">Solusi</label>
                                                    <textarea name="solusi" id="solusi" class="form-control"><?= esc($row['solusi']) ?></textarea>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('solusi'); ?>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <input type="hidden" name="status" id="status" value="selesai" class="form-control"></input>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('status'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit -->
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data konsultasi</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<!-- Modal Detail Janji Temu -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="detailModalLabel">Detail Janji Temu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Tanggal Janji Temu</th>
                        <td id="modalTanggal"></td>
                    </tr>
                    <tr>
                        <th>Nama Mahasiswa</th>
                        <td id="modalMahasiswa"></td>
                    </tr>
                    <tr>
                        <th>Nama Dosen</th>
                        <td id="modalDosen"></td>
                    </tr>
                    <tr>
                        <th>Kategori Keluhan</th>
                        <td id="modalKategori"></td>
                    </tr>
                    <tr>
                        <th>Jam Mulai</th>
                        <td id="modalJamMulai"></td>
                    </tr>
                    <tr>
                        <th>Jam Selesai</th>
                        <td id="modalJamSelesai"></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td id="modalStatus"></td>
                    </tr>
                    <tr>
                        <th>Keterangan</th>
                        <td id="modalKeterangan"></td>
                    </tr>
                    <tr>
                        <th>Diupdate Oleh</th>
                        <td id="modalUpdatedBy"></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script>
    var detailModal = document.getElementById('detailModal');
    detailModal.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        var tanggal = button.getAttribute('data-tanggal');
        var mahasiswa = button.getAttribute('data-mahasiswa');
        var dosen = button.getAttribute('data-dosen');
        var kategori = button.getAttribute('data-kategori');
        var jam_mulai = button.getAttribute('data-jam_mulai');
        var jam_selesai = button.getAttribute('data-jam_selesai');
        var status = button.getAttribute('data-status');
        var keterangan = button.getAttribute('data-keterangan');
        var updated_by = button.getAttribute('data-updated_by');

        document.getElementById('modalTanggal').textContent = tanggal;
        document.getElementById('modalMahasiswa').textContent = mahasiswa;
        document.getElementById('modalDosen').textContent = dosen;
        document.getElementById('modalKategori').textContent = kategori;
        document.getElementById('modalJamMulai').textContent = jam_mulai;
        document.getElementById('modalJamSelesai').textContent = jam_selesai;
        document.getElementById('modalStatus').textContent = status;
        document.getElementById('modalKeterangan').textContent = keterangan;
        document.getElementById('modalUpdatedBy').textContent = updated_by;
    });
</script>

<?= $this->endSection(); ?>