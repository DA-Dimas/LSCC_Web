<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\FormKonsultasiModel;
use CodeIgniter\HTTP\ResponseInterface;

class LaporanJanjiTemuController extends BaseController
{
    public function index()
    {
        $konsultasi_model = new FormKonsultasiModel();

        $username = session()->get('username');

        // Ambil data konsultasi dengan join tabel dosen
        $janji_temu = $konsultasi_model
            ->select('konsultasi.*, dosen.nama as nama_dosen, mahasiswa.nama as nama_mahasiswa, kategori.kategori, user.role as penyetuju')
            ->join('dosen', 'dosen.id = konsultasi.id_dosen', 'left')
            ->join('kategori', 'kategori.id = konsultasi.id_kategori', 'left')
            ->join('mahasiswa', 'mahasiswa.id = konsultasi.id_mahasiswa', 'left')
            ->join('user', 'user.id = konsultasi.updated_by', 'left')
            ->where('mahasiswa.nim', $username)
            ->orderBy('konsultasi.id', 'DESC')
            ->findAll();

        $data = [
            'title' => 'Laporan Janji Temu',
            'janji_temu' => $janji_temu,
            'validation' => \Config\Services::validation(),
        ];

        return view('mahasiswa/laporan_janji_temu', $data);
    }

    public function update($id)
    {
        $janjiTemuModel = new FormKonsultasiModel();

        $rules = [
            'status' => 'required',
            'keterangan' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $status = $this->request->getPost('status');
        $keterangan = $this->request->getPost('keterangan');
        $id_user = session()->get('id');

        $data = [
            'status' => $status,
            'keterangan' => $keterangan,
            'updated_by' => $id_user,
        ];

        $janjiTemuModel->update($id, $data);

        return redirect()->to(base_url('mahasiswa/laporan_janji_temu'))->with('success', 'Janji temu berhasil diperbarui.');
    }
}
