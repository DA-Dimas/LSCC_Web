<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\DosenModel;
use App\Models\FormKonsultasiModel;
use App\Models\MahasiswaModel;
use App\Models\UserModel;
use App\Models\KategoriModel;
use App\Models\ProdiModel;

class JanjiTemuMahasiswaController extends BaseController
{
    protected $dosenModel;
    protected $mahasiswaModel;
    protected $janjiTemuModel;
    protected $userModel;
    protected $kategoriModel;
    protected $prodiModel;
    protected $konsultasiModel;

    public function __construct()
    {
        $this->dosenModel = new DosenModel();
        $this->mahasiswaModel = new MahasiswaModel();
        $this->userModel = new UserModel();
        $this->kategoriModel = new KategoriModel();
        $this->prodiModel = new ProdiModel();
        $this->konsultasiModel = new FormKonsultasiModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Form Janji Temu',
            'janjiTemu' => $this->konsultasiModel->findAll(),
            'dosen' => $this->dosenModel->getAllDosenWithUser(), // Ambil semua dosen yang punya akun
            'user' => session()->get('username'),
            'kategori' => $this->kategoriModel->findAll(),
            'prodi' => $this->prodiModel->findAll(),
            'mahasiswa' => $this->mahasiswaModel->getMahasiswa(),
            'validation' => \Config\Services::validation()
        ];

        return view('mahasiswa/janji_temu', $data);
    }

    public function save()
    {
        $validation = \Config\Services::validation();

        // Aturan validasi
        $rules = [
            'id_mahasiswa' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Mahasiswa wajib diisi!'
                ],
            ],
            'id_dosen' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Dosen wajib diisi!'
                ],
            ],
            'id_kategori' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kategori wajib diisi!'
                ],
            ],
            'tanggal_konsultasi' => [
                'rules' => 'required|valid_date',
                'errors' => [
                    'required' => 'Tanggal wajib diisi!'
                ],
            ],
            'jam_mulai' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Jam Mulai wajib diisi!'
                ],
            ],
            'jam_selesai' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Jam Selesai wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $data = [
            'id_mahasiswa' => $this->request->getPost('id_mahasiswa'),
            'id_dosen' => $this->request->getPost('id_dosen'),
            'tanggal_konsultasi' => $this->request->getPost('tanggal_konsultasi'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'jam_mulai' => $this->request->getPost('jam_mulai'),
            'jam_selesai' => $this->request->getPost('jam_selesai')
        ];

        $this->konsultasiModel->insert($data);

        return redirect()->to(base_url('mahasiswa/janji_temu'))->with('success', 'Janji Temu berhasil disimpan.');
    }
}
