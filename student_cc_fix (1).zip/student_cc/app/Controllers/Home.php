<?php

namespace App\Controllers;

use App\Models\DosenModel;
use App\Models\MahasiswaModel;
use App\Models\FormKonsultasiModel;

class Home extends BaseController
{
    public function index(): string
    {
        $mahasiswa = new MahasiswaModel();
        $dosen = new DosenModel();
        $konsultasi = new FormKonsultasiModel();
        $data = [
            'title' => 'Dashboard',
            'mahasiswa' => $mahasiswa->getTotalMahasiswa(),
            'dosen' => $dosen->getTotalKonseler(),
            'konsultasi' => $konsultasi->getTotalKonsultasi(),
        ];
        return view('index', $data);
    }

    public function konselor()
    {
        $dosen_model = new DosenModel();
        $data = [
            'title' => 'Konselor',
            'dosen' => $dosen_model->findAll()
        ];
        return view('konselor', $data);
    }
}
