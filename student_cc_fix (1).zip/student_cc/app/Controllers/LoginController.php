<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\UserModel;

class LoginController extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Login',
            'validation' => \Config\Services::validation()
        ];
        return view('login', $data);
    }

    public function login_action()
    {
        $rules = [
            'username' => 'required',
            'password' => 'required'
        ];

        if (!$this->validate($rules)) {
            $data = [
                'title' => 'Login',
                'validation' => \Config\Services::validation()
            ];
            return view('login', $data);
        }

        $session = session();
        $user_model = new UserModel();

        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');

        $user = $user_model->where('username', $username)->first();

        if ($user) {
            $password_db = $user['password'];

            if (password_verify($password, $password_db)) {
                $session = session();

                $session->set([
                    'username' => $user['username'],
                    'logged_in' => TRUE,
                    'role' => $user['role'],
                    'id' => $user['id'],
                ]);

                $session->setFlashdata('success', $user['username'] . ' berhasil login!');

                switch ($user['role']) {
                    case 'Dosen':
                        return redirect()->to('dosen/dashboard');
                    case 'Admin':
                        return redirect()->to('admin/dashboard');
                    case 'Pembimbing Akademik':
                        return redirect()->to('pa/dashboard');
                    case 'Mahasiswa':
                        return redirect()->to('mahasiswa/janji_temu');
                    default:
                        $session->setFlashdata('error', 'Akun anda belum terdaftar!');
                        return redirect()->to('login');
                }
            } else {
                $session->setFlashdata('error', 'Password Salah!');
                return redirect()->to('login');
            }
        } else {
            $session->setFlashdata('error', 'Username tidak ditemukan, silahkan coba kembali!');
            return redirect()->to('login');
        }
    }

    public function logout()
    {
        $session = session();
        $session->setFlashdata('logout_success', 'Anda berhasil logout!');
        $session->destroy();
        return redirect()->to('login');
    }
}
