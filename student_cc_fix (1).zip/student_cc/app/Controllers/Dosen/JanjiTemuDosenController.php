<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\DosenModel;
use App\Models\FormKonsultasiModel;

class JanjiTemuDosenController extends BaseController
{
    public function index()
    {
        $janji_temu_model = new FormKonsultasiModel();

        $username = session()->get('username');

        // Ambil data konsultasi dengan join tabel dosen
        $janji_temu = $janji_temu_model
            ->select('konsultasi.*, dosen.nama as nama_dosen, mahasiswa.nama as nama_mahasiswa, kategori.kategori, user.role as penyetuju')
            ->join('dosen', 'dosen.id = konsultasi.id_dosen', 'left')
            ->join('kategori', 'kategori.id = konsultasi.id_kategori', 'left')
            ->join('mahasiswa', 'mahasiswa.id = konsultasi.id_mahasiswa', 'left')
            ->join('user', 'user.id = konsultasi.updated_by', 'left')
            ->where('dosen.nidn', $username)
            ->orderBy('konsultasi.id', 'DESC')
            ->findAll();
        
        $notif = $janji_temu_model
            ->select('konsultasi.*')
            ->join('dosen', 'dosen.id = konsultasi.id_dosen', 'left')
            ->where('dosen.nidn', $username)
            ->where('konsultasi.status', 'proses')
            ->countAllResults();

        $data = [
            'title' => 'Laporan Janji Temu',
            'janji_temu' => $janji_temu,
            'notif' => $notif,
            'validation' => \Config\Services::validation()
        ];

        return view('dosen/janji_temu', $data);
    }

    public function update($id)
    {
        $janjiTemuModel = new FormKonsultasiModel();
        $dosenModel = new DosenModel();

        $rules = [
            'status' => 'required',
            'keterangan' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $status = $this->request->getPost('status');
        $keterangan = $this->request->getPost('keterangan');
        $id_user = session()->get('id');

        $data = [
            'status' => $status,
            'keterangan' => $keterangan,
            'updated_by' => $id_user,
        ];

        $janjiTemuModel->update($id, $data);

        return redirect()->to(base_url('dosen/janji_temu'))->with('success', 'Janji temu berhasil diperbarui.');
    }

    public function konsul($id)
    {
        $janjiTemuModel = new FormKonsultasiModel();
        $dosenModel = new DosenModel();

        $rules = [
            'catatan' => 'required',
            'solusi' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $catatan = $this->request->getPost('catatan');
        $solusi = $this->request->getPost('solusi');
        $status = $this->request->getPost('status');

        $data = [
            'catatan' => $catatan,
            'solusi' => $solusi,
            'status' => $status,
        ];

        $janjiTemuModel->update($id, $data);

        return redirect()->to(base_url('dosen/janji_temu'))->with('success', 'Konsultasi selesai.');
    }
}
