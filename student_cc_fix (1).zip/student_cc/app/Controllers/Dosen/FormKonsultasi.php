<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use App\Models\MahasiswaModel;
use App\Models\ProdiModel;
use App\Models\DosenModel;
use App\Models\FormKonsultasiModel;
use App\Models\KategoriModel;

class FormKonsultasi extends BaseController
{
    public function __construct()
    {
        helper('form');
    }

    public function index()
    {
        $prodiModel = new ProdiModel();
        $mahasiswaModel = new MahasiswaModel();
        $dosenModel = new DosenModel();
        $kategoriModel = new KategoriModel();

        $prodi = $prodiModel->findAll();
        $kategori = $kategoriModel->findAll();
        $dosen = $dosenModel->getDosen();
        $mahasiswa = [];

        $id_prodi = (int) $this->request->getPost('id_prodi') ?? '';
        $tingkat = $this->request->getPost('tingkat') ?? '';

        if (!empty($id_prodi) && !empty($tingkat)) {
            $mahasiswa = $mahasiswaModel->where('id_prodi', $id_prodi)
                ->where('tingkat', $tingkat)
                ->findAll();
        }

        $data = [
            'title' => 'Form Konsultasi',
            'prodi' => $prodi,
            'dosen' => $dosen,
            'mahasiswa' => $mahasiswa,
            'kategori' => $kategori,
            'selected_prodi' => $id_prodi,
            'selected_tingkat' => $tingkat
        ];

        return view('dosen/form_konsultasi', $data);
    }


    public function submit()
    {
        $validation = \Config\Services::validation();

        // Aturan validasi
        $rules = [
            'id_mahasiswa' => 'required',
            'id_dosen' => 'required',
            'tanggal_konsultasi' => 'required|valid_date',
            'id_kategori' => 'required',
            'catatan' => 'required',
            'solusi' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $data = [
            'id_mahasiswa' => $this->request->getPost('id_mahasiswa'),
            'id_dosen' => $this->request->getPost('id_dosen'),
            'tanggal_konsultasi' => $this->request->getPost('tanggal_konsultasi'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'catatan' => $this->request->getPost('catatan'),
            'solusi' => $this->request->getPost('solusi')
        ];

        $konsultasiModel = new FormKonsultasiModel();
        $konsultasiModel->insert($data);

        return redirect()->to('dosen/form_konsultasi')->with('success', 'Data konsultasi berhasil disimpan.');
    }
}
