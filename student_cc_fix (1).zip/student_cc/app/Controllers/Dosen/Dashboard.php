<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\DosenModel;
use App\Models\MahasiswaModel;
use App\Models\FormKonsultasiModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $mahasiswa = new MahasiswaModel();
        $dosen = new DosenModel();
        $konsultasi = new FormKonsultasiModel();

        $username = session()->get('username');

        $notif = $konsultasi
            ->select('konsultasi.*')
            ->join('dosen', 'dosen.id = konsultasi.id_dosen', 'left')
            ->where('dosen.nidn', $username)
            ->where('konsultasi.status', 'proses')
            ->countAllResults();

        $data = [
            'title' => 'Dashboard',
            'mahasiswa' => $mahasiswa->getTotalMahasiswa(),
            'dosen' => $dosen->getTotalKonseler(),
            'konsultasi' => $konsultasi->getTotalKonsultasi(),
            'notif' => $notif
        ];
        return view('dosen/dashboard', $data);
    }
}
