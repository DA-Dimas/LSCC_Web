<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\UserModel;
use App\Models\FormKonsultasiModel;
use finfo;

class User extends BaseController
{
    public function index()
    {
        $user_model = new UserModel();
        $konsultasi = new FormKonsultasiModel();

        $notif = $konsultasi
            ->select('konsultasi.*')
            ->where('konsultasi.status', 'disetujui_dosen')
            ->countAllResults();

        $perPage = $user_model->getTotalUser();
        $user = $user_model->getAllUser($perPage, 0);

        $data = [
            'title' => 'Data user',
            'user' => $user,
            'validation' => \Config\Services::validation(),
            'notif' => $notif,
            'user_id' => $user_model->generateIdUser()
        ];

        return view('admin/user', $data);
    }

    public function save()
    {
        $rules = [
            'username' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Username wajib diisi!'
                ],
            ],
            'password' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'password wajib diisi!'
                ],
            ],
            'role' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Role wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        }

        $user_model = new UserModel();
        $user_id = $this->request->getPost('id');

        $user_model->insert([
            'id' => $user_id,
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role' => $this->request->getPost('role'),
        ]);

        session()->setFlashdata('success', 'Data user berhasil tersimpan!');
        return redirect()->to(base_url('admin/user'));
    }

    public function edit($id)
    {
        $user_model = new UserModel();
        $user = $user_model->find($id);

        if (!$user) {
            return $this->response->setJSON(['error' => 'Data user tidak ditemukan'])->setStatusCode(404);
        }

        return view('admin/user_edit_modal', [
            'user' => $user,
            'id' => $id,
            'validation' => \Config\Services::validation()
        ]);
    }

    public function update($id)
    {
        $rules = [
            'username' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Username wajib diisi!'
                ],
            ],
            'role' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Role wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        }

        $user_model = new UserModel();

        // Cek apakah password diisi atau tidak
        $password_input = $this->request->getPost('password');
        if (empty($password_input)) {
            // Jika password kosong, gunakan password lama
            $password = $this->request->getPost('password_lama');
        } else {
            // Jika password diisi, hash password baru
            $password = password_hash($password_input, PASSWORD_DEFAULT);
        }

        // Data yang akan diupdate
        $updateData = [
            'username' => $this->request->getPost('username'),
            'password' => $password,
            'role' => $this->request->getPost('role'),
        ];

        $user_model->update($id, $updateData);

        session()->setFlashdata('success', 'Data user berhasil diperbaharui!');
        return redirect()->to(base_url('admin/user'));
    }

    public function delete($id)
    {
        $user_model = new UserModel();

        if ($user_model->find($id)) {
            $user_model->delete($id);
            session()->setFlashdata('success', 'Data user berhasil dihapus!');
        }

        return redirect()->to(base_url('admin/user'));
    }
}
