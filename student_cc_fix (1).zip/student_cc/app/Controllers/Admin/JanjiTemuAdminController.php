<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\FormKonsultasiModel;
use App\Models\UserModel;
use CodeIgniter\HTTP\ResponseInterface;

class JanjiTemuAdminController extends BaseController
{
    public function index()
    {
        $janji_temu_model = new FormKonsultasiModel();

        // Ambil data konsultasi dengan join tabel dosen
        $janji_temu = $janji_temu_model
            ->select('konsultasi.*, dosen.nama as nama_dosen, mahasiswa.nama as nama_mahasiswa, kategori.kategori, user.role as penyetuju')
            ->join('dosen', 'dosen.id = konsultasi.id_dosen', 'left')
            ->join('kategori', 'kategori.id = konsultasi.id_kategori', 'left')
            ->join('mahasiswa', 'mahasiswa.id = konsultasi.id_mahasiswa', 'left')
            ->join('user', 'user.id = konsultasi.updated_by', 'left')
            ->orderBy('konsultasi.id', 'DESC')
            ->findAll();

        $notif = $janji_temu_model
            ->select('konsultasi.*')
            ->where('konsultasi.status', 'disetujui_dosen')
            ->countAllResults();

        $data = [
            'title' => 'Laporan Janji Temu',
            'janji_temu' => $janji_temu,
            'notif' => $notif,
            'validation' => \Config\Services::validation()
        ];

        return view('admin/laporan_janji_temu', $data);
    }

    public function update($id)
    {
        $janjiTemuModel = new FormKonsultasiModel();

        $rules = [
            'status' => 'required',
            'keterangan' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $status = $this->request->getPost('status');
        $keterangan = $this->request->getPost('keterangan');
        $id_user = session()->get('id');

        $data = [
            'status' => $status,
            'keterangan' => $keterangan,
            'updated_by' => $id_user,
        ];

        $janjiTemuModel->update($id, $data);

        return redirect()->to(base_url('admin/laporan_janji_temu'))->with('success', 'Janji temu berhasil diperbarui.');
    }
}
