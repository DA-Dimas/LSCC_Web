<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\KelasModel;
use App\Models\ProdiModel;
use CodeIgniter\HTTP\ResponseInterface;

class Kelas extends BaseController
{
    public function index()
    {
        $kelas_model = new KelasModel();

        $data = [
            'title' => 'Data Kelas',
            'kelas' => $kelas_model->getProdi(),
            'validation' => \Config\Services::validation()
        ];

        return view('admin/kelas', $data);
    }
}
