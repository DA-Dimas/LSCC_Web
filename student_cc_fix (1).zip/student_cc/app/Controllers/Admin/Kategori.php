<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\KategoriModel;
use App\Models\FormKonsultasiModel;

class Kategori extends BaseController
{
    public function index()
    {
        $kategori_model = new KategoriModel();
        $konsultasi = new FormKonsultasiModel();

        $notif = $konsultasi
        ->select('konsultasi.*')
        ->where('konsultasi.status', 'disetujui_dosen')
        ->countAllResults();

        $data = [
            'title' => 'Data Kategori Keluhan',
            'kategori' => $kategori_model->findAll(),
            'validation' => \Config\Services::validation(),
            'notif' => $notif
        ];

        return view('admin/kategori', $data);
    }

    public function save() {
        $rules = [
            'kategori' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kategori wajib diisi!'
                ],
            ],
        ];

        if(!$this->validate($rules)){
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        } else {
            $kategori_model = new KategoriModel();
            $kategori_model->insert([
                'kategori' => $this->request->getPost('kategori')
            ]);

            session()->setFlashData('success','Data kategori berhasil tersimpan!');

            return redirect()->to(base_url('admin/kategori'));
        }
    }

    public function update($id_prodi) {
        $rules = [
            'kategori' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kategori wajib diisi!'
                ],
            ],
        ];

        if(!$this->validate($rules)){
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        } else {
            $kategori_model = new KategoriModel();
            $kategori_model->update($id_prodi,[
                'kategori' => $this->request->getPost('kategori')
            ]);

            session()->setFlashData('success','Data kategori berhasil diperbaharui!');

            return redirect()->to(base_url('admin/kategori'));
        }
    }

    public function delete($id_prodi) 
    {
        $kategori_model = new KategoriModel();

        $kategori = $kategori_model->find($id_prodi);
        if($kategori){
            $kategori_model->delete($id_prodi);
            session()->setFlashData('success','Data jabatan berhasil dihapus!');

            return redirect()->to(base_url('admin/kategori'));
        }
    }
}
