<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\DosenModel;
use App\Models\MahasiswaModel;
use App\Models\FormKonsultasiModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $mahasiswa = new MahasiswaModel();
        $dosen = new DosenModel();
        $konsultasi = new FormKonsultasiModel();

        $notif = $konsultasi
            ->select('konsultasi.*')
            ->where('konsultasi.status', 'disetujui_dosen')
            ->countAllResults();

        $data = [
            'title' => 'Dashboard',
            'mahasiswa' => $mahasiswa->getTotalMahasiswa(),
            'dosen' => $dosen->getTotalKonseler(),
            'konsultasi' => $konsultasi->getTotalKonsultasi(),
            'notif' => $notif,
        ];
        return view('admin/dashboard', $data);
    }
}
