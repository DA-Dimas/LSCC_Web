<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\ProdiModel;
use App\Models\FormKonsultasiModel;

class Prodi extends BaseController
{
    public function index()
    {
        $prodi_model = new ProdiModel();
        $konsultasi = new FormKonsultasiModel();

        $notif = $konsultasi
        ->select('konsultasi.*')
        ->where('konsultasi.status', 'disetujui_dosen')
        ->countAllResults();

        $data = [
            'title' => 'Data Prodi',
            'prodi' => $prodi_model->findAll(),
            'validation' => \Config\Services::validation(),
            'notif' => $notif
        ];

        return view('admin/prodi', $data);
    }

    public function save()
    {
        $rules = [
            'prodi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Prodi wajib diisi!'
                ],
            ],
            'kelas' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kelas wajib diisi!'
                ],
            ],
            'tingkat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Tingkat wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        } else {
            $prodi_model = new ProdiModel();
            $prodi_model->insert([
                'prodi' => $this->request->getPost('prodi'),
                'kelas' => $this->request->getPost('kelas'),
                'tingkat' => $this->request->getPost('tingkat'),
            ]);

            session()->setFlashData('success', 'Data prodi berhasil tersimpan!');

            return redirect()->to(base_url('admin/prodi'));
        }
    }

    public function update($id_prodi)
    {
        $rules = [
            'prodi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Prodi wajib diisi!'
                ],
            ],
            'kelas' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kelas wajib diisi!'
                ],
            ],
            'tingkat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Tingkat wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        } else {
            $prodi_model = new ProdiModel();
            $prodi_model->update($id_prodi, [
                'prodi' => $this->request->getPost('prodi'),
                'kelas' => $this->request->getPost('kelas'),
                'tingkat' => $this->request->getPost('tingkat'),
            ]);

            session()->setFlashData('success', 'Data prodi berhasil diperbaharui!');

            return redirect()->to(base_url('admin/prodi'));
        }
    }

    public function delete($id_prodi)
    {
        $prodi_model = new ProdiModel();

        $prodi = $prodi_model->find($id_prodi);
        if ($prodi) {
            $prodi_model->delete($id_prodi);
            session()->setFlashData('success', 'Data prodi berhasil dihapus!');

            return redirect()->to(base_url('admin/prodi'));
        }
    }
}
