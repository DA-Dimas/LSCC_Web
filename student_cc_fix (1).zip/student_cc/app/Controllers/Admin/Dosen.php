<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\DosenModel;
use App\Models\FormKonsultasiModel;
use App\Models\UserModel;

class Dosen extends BaseController
{
    public function index()
    {
        $dosen_model = new DosenModel();
        $konsultasi = new FormKonsultasiModel();
        $user_model = new UserModel();

        $notif = $konsultasi
            ->select('konsultasi.*')
            ->where('konsultasi.status', 'disetujui_dosen')
            ->countAllResults();

        $data = [
            'title' => 'Data Dosen',
            'dosen' => $dosen_model->findAll(),
            'validation' => \Config\Services::validation(),
            'notif' => $notif,
            'user' => $user_model->generateIdUser()
        ];

        return view('admin/dosen', $data);
    }

    public function save()
    {
        $rules = [
            'nidn' => [
                'rules'  => 'required|is_unique[dosen.nidn]',
                'errors' => [
                    'required'   => 'NIDN wajib diisi!',
                    'is_unique'  => 'NIDN sudah terdaftar!',
                ],
            ],
            'nama' => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Nama Dosen wajib diisi!',
                ],
            ],
            'jabatan' => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Jabatan Dosen wajib diisi!',
                ],
            ],
            'foto' => [
                'rules'  => 'max_size[foto,10240]|is_image[foto]|mime_in[foto,image/png,image/jpg,image/jpeg]',
                'errors' => [
                    'max_size'  => 'Ukuran foto tidak boleh lebih dari 10MB!',
                    'is_image'  => 'File yang diunggah harus berupa gambar!',
                    'mime_in'   => 'Format gambar yang diperbolehkan hanya PNG, JPG, atau JPEG!',
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        }

        $user_id = $this->request->getPost('id');

        $user_model = new UserModel();
        $user_model->insert([
            'id' => $user_id,
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role' => $this->request->getPost('role'),
        ]);

        $dosen_model = new DosenModel();
        $foto = $this->request->getFile('foto');

        // Simpan foto jika valid
        if ($foto->isValid() && !$foto->hasMoved()) {
            $namaFoto = $foto->getRandomName();
            $foto->move(FCPATH . 'assets/img/profile_dosen', $namaFoto);
        } else {
            $namaFoto = null; // Tidak ada foto diunggah
        }

        // Simpan data ke database
        $dosen_model->insert([
            'id_user' => $user_id,
            'nidn' => $this->request->getPost('nidn'),
            'nama' => $this->request->getPost('nama'),
            'jabatan' => $this->request->getPost('jabatan'),
            'foto' => $namaFoto,
            'no_wa' => $this->request->getPost('no_wa'),
            'instagram' => $this->request->getPost('instagram')
        ]);

        session()->setFlashdata('success', 'Data dosen berhasil disimpan!');
        return redirect()->to(base_url('admin/dosen'));
    }

    public function edit($dosen_id)
    {
        $dosen_model = new DosenModel();
        $user_model = new UserModel();

        // Cari data dosen berdasarkan ID dosen
        $dosen = $dosen_model->find($dosen_id);

        if (!$dosen) {
            return $this->response->setJSON(['error' => 'Data dosen tidak ditemukan'])->setStatusCode(404);
        }

        // Cari data user berdasarkan id_user dari dosen
        $user = $user_model->find($dosen['id_user']);
        if (!$user) {
            return $this->response->setJSON(['error' => 'Data user tidak ditemukan'])->setStatusCode(404);
        }

        return view('admin/dosen_edit_modal', [
            'd' => $dosen,
            'user' => $user,
            'dosen_id' => $dosen_id,
            'validation' => \Config\Services::validation()
        ]);
    }

    public function update($dosen_id)
    {
        $rules = [
            'nidn' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'NIDN wajib diisi!'
                ],
            ],
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nama Dosen wajib diisi!'
                ],
            ],
            'jabatan' => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Jabatan Dosen wajib diisi!',
                ],
            ],
            'foto' => [
                'rules' => 'max_size[foto,10240]|mime_in[foto,image/png,image/jpg,image/jpeg]|is_image[foto]',
                'errors' => [
                    'max_size' => 'Ukuran foto melebihi 10MB',
                    'mime_in'  => 'Jenis file yang diizinkan hanya .png, .jpg, dan .jpeg',
                    'is_image' => 'File yang diunggah harus berupa gambar'
                ],
            ],
            'no_wa' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nomor WhatsApp Dosen wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        }

        $dosen_model = new DosenModel();
        // Cari dosen berdasarkan ID dosen
        $dosen = $dosen_model->find($dosen_id);

        if (!$dosen) {
            return redirect()->back()->with('error', 'Data dosen tidak ditemukan');
        }

        $user_model = new UserModel();

        // Handle password update
        if ($this->request->getPost('password') == '') {
            $password = $this->request->getPost('password_lama');
        } else {
            $password = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);
        }

        // Update data user berdasarkan id_user dari dosen
        $user_model->update($dosen['id_user'], [
            'username' => $this->request->getPost('username'),
            'password' => $password,
            'role' => $this->request->getPost('role'),
        ]);

        $foto = $this->request->getFile('foto');
        $fotoLama = $dosen['foto'];

        if ($foto && $foto->isValid() && !$foto->hasMoved()) {
            $nama_foto = $foto->getRandomName();
            $foto->move(FCPATH . 'assets/img/profile_dosen', $nama_foto);

            // hapus foto lama kalau beda dan bukan default
            if ($fotoLama && file_exists(FCPATH . 'assets/img/profile_dosen/' . $fotoLama)) {
                unlink(FCPATH . 'assets/img/profile_dosen/' . $fotoLama);
            }
        } else {
            $nama_foto = $this->request->getPost('foto_lama'); // pakai yang lama
        }

        // Update data dosen berdasarkan ID dosen
        $dosen_model->update($dosen_id, [
            'nidn' => $this->request->getPost('nidn'),
            'nama' => $this->request->getPost('nama'),
            'jabatan' => $this->request->getPost('jabatan'),
            'foto' => $nama_foto,
            'no_wa' => $this->request->getPost('no_wa'),
            'instagram' => $this->request->getPost('instagram')
        ]);

        session()->setFlashData('success', 'Data dosen berhasil diperbarui!');
        return redirect()->to('admin/dosen');
    }

    public function delete($dosen_id)
    {
        $dosen_model = new DosenModel();
        // Cari dosen berdasarkan ID dosen
        $dosen = $dosen_model->find($dosen_id);

        if ($dosen) {
            // Hapus data dosen berdasarkan ID dosen
            $dosen_model->delete($dosen_id);

            // Hapus data user terkait berdasarkan id_user dari dosen
            $user_model = new UserModel();
            $user_model->delete($dosen['id_user']);

            session()->setFlashdata('success', 'Data dosen berhasil dihapus!');
        } else {
            session()->setFlashdata('error', 'Data dosen tidak ditemukan!');
        }

        return redirect()->to(base_url('admin/dosen'));
    }
}
