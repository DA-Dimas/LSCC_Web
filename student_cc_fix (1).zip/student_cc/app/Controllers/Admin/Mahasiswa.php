<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\MahasiswaModel;
use App\Models\ProdiModel;
use App\Models\FormKonsultasiModel;
use App\Models\UserModel;

class Mahasiswa extends BaseController
{
    public function index()
    {
        $mahasiswa_model = new MahasiswaModel();
        $prodi_model = new ProdiModel();
        $konsultasi = new FormKonsultasiModel();
        $user_model = new UserModel();

        $notif = $konsultasi
            ->select('konsultasi.*')
            ->where('konsultasi.status', 'disetujui_dosen')
            ->countAllResults();

        $perPage = $mahasiswa_model->getTotalMahasiswa();
        $mahasiswa = $mahasiswa_model->getAllMahasiswa($perPage, 0);

        $data = [
            'title' => 'Data Mahasiswa',
            'mahasiswa' => $mahasiswa,
            'user' => $user_model->generateIdUser(),
            'ambil_prodi' => $prodi_model->findAll(),
            'validation' => \Config\Services::validation(),
            'notif' => $notif,
        ];

        return view('admin/mahasiswa', $data);
    }

    public function save()
    {
        $rules = [
            'nim' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'NIM wajib diisi!'
                ],
            ],
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nama wajib diisi!'
                ],
            ],
            'id_prodi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Prodi wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        }

        $user_id = $this->request->getPost('id');

        $user_model = new UserModel();
        $user_model->insert([
            'id' => $user_id,
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role' => $this->request->getPost('role'),
        ]);

        $mahasiswa_model = new MahasiswaModel();
        $mahasiswa_model->insert([
            'id_user' => $user_id, // Gunakan user_id yang sama
            'nim' => $this->request->getPost('nim'),
            'nama' => $this->request->getPost('nama'),
            'id_prodi' => $this->request->getPost('id_prodi'),
        ]);

        session()->setFlashdata('success', 'Data mahasiswa berhasil tersimpan!');
        return redirect()->to(base_url('admin/mahasiswa'));
    }

    public function edit($mahasiswa_id)
    {
        $mahasiswa_model = new MahasiswaModel();
        $prodi_model = new ProdiModel();
        $user_model = new UserModel();

        // Cari data mahasiswa berdasarkan ID mahasiswa
        $mahasiswa = $mahasiswa_model->find($mahasiswa_id);

        if (!$mahasiswa) {
            return $this->response->setJSON(['error' => 'Data mahasiswa tidak ditemukan'])->setStatusCode(404);
        }

        // Cari data user berdasarkan id_user dari mahasiswa
        $user = $user_model->find($mahasiswa['id_user']);
        if (!$user) {
            return $this->response->setJSON(['error' => 'Data user tidak ditemukan'])->setStatusCode(404);
        }

        $prodi = $prodi_model->findAll();

        return view('admin/mahasiswa_edit_modal', [
            'm' => $mahasiswa,
            'prodi' => $prodi,
            'user' => $user,
            'mahasiswa_id' => $mahasiswa_id,
        ]);
    }

    public function update($mahasiswa_id)
    {
        $rules = [
            'nim' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'NIM wajib diisi!'
                ],
            ],
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nama wajib diisi!'
                ],
            ],
            'id_prodi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Prodi wajib diisi!'
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', \Config\Services::validation());
        }

        $mahasiswa_model = new MahasiswaModel();
        // Cari mahasiswa berdasarkan ID mahasiswa
        $mahasiswa = $mahasiswa_model->find($mahasiswa_id);

        if (!$mahasiswa) {
            return redirect()->back()->with('error', 'Data mahasiswa tidak ditemukan');
        }

        $user_model = new UserModel();

        // Handle password update
        if ($this->request->getPost('password') == '') {
            $password = $this->request->getPost('password_lama');
        } else {
            $password = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);
        }

        // Update data user berdasarkan id_user dari mahasiswa
        $user_model->update($mahasiswa['id_user'], [
            'username' => $this->request->getPost('username'),
            'password' => $password,
            'role' => $this->request->getPost('role'),
        ]);

        // Update data mahasiswa berdasarkan ID mahasiswa
        $mahasiswa_model->update($mahasiswa_id, [
            'nim' => $this->request->getPost('nim'),
            'nama' => $this->request->getPost('nama'),
            'id_prodi' => $this->request->getPost('id_prodi'),
        ]);

        session()->setFlashdata('success', 'Data mahasiswa berhasil diperbaharui!');
        return redirect()->to(base_url('admin/mahasiswa'));
    }

    public function delete($mahasiswa_id)
    {
        $mahasiswa_model = new MahasiswaModel();
        // Cari mahasiswa berdasarkan ID mahasiswa
        $mahasiswa = $mahasiswa_model->find($mahasiswa_id);

        if ($mahasiswa) {
            // Hapus data mahasiswa berdasarkan ID mahasiswa
            $mahasiswa_model->delete($mahasiswa_id);

            // Hapus data user terkait berdasarkan id_user dari mahasiswa
            $user_model = new UserModel();
            $user_model->delete($mahasiswa['id_user']);

            session()->setFlashdata('success', 'Data mahasiswa berhasil dihapus!');
        } else {
            session()->setFlashdata('error', 'Data mahasiswa tidak ditemukan!');
        }

        return redirect()->to(base_url('admin/mahasiswa'));
    }
}
