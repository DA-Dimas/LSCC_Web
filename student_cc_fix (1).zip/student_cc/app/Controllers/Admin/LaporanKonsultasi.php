<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\FormKonsultasiModel;
use App\Models\DosenModel;

class LaporanKonsultasi extends BaseController
{
    public function index()
    {
        $konsultasi_model = new FormKonsultasiModel();

        // Ambil input filter
        $filter_tahun       = $this->request->getGet('filter_tahun');
        $filter_bulan_awal  = $this->request->getGet('filter_bulan_awal');
        $filter_bulan_akhir = $this->request->getGet('filter_bulan_akhir');

        // Query builder
        $builder = $konsultasi_model
            ->select('konsultasi.*, dosen.nama as nama_dosen, mahasiswa.nama as nama_mahasiswa, kategori.kategori')
            ->join('dosen', 'dosen.id = konsultasi.id_dosen', 'left')
            ->join('kategori', 'kategori.id = konsultasi.id_kategori', 'left')
            ->join('mahasiswa', 'mahasiswa.id = konsultasi.id_mahasiswa', 'left')
            ->where('konsultasi.catatan IS NOT NULL AND konsultasi.catatan != ""')
            ->where('konsultasi.solusi IS NOT NULL AND konsultasi.solusi != ""')
            ->orderBy('konsultasi.id', 'DESC');

        // Tambahkan filter
        if (!empty($filter_tahun) && !empty($filter_bulan_awal) && !empty($filter_bulan_akhir)) {
            $builder->where('YEAR(konsultasi.tanggal_konsultasi)', $filter_tahun);
            $builder->where('MONTH(konsultasi.tanggal_konsultasi) >=', $filter_bulan_awal);
            $builder->where('MONTH(konsultasi.tanggal_konsultasi) <=', $filter_bulan_akhir);
        }

        $konsultasi = $builder->orderBy('konsultasi.tanggal_konsultasi', 'DESC')->findAll();

        // Ambil semua tahun unik
        $tahun_result = $konsultasi_model
            ->select('YEAR(tanggal_konsultasi) as tahun')
            ->groupBy('YEAR(tanggal_konsultasi)')
            ->orderBy('tahun', 'DESC')
            ->findAll();

        $tahun_list = array_map(fn($item) => $item['tahun'], $tahun_result);

        $notif = $konsultasi_model
            ->select('konsultasi.*')
            ->where('konsultasi.status', 'disetujui_dosen')
            ->countAllResults();

        $data = [
            'title' => 'Laporan Konsultasi',
            'konsultasi' => $konsultasi,
            'filter_tahun' => $filter_tahun,
            'filter_bulan_awal' => $filter_bulan_awal,
            'filter_bulan_akhir' => $filter_bulan_akhir,
            'tahun_list' => $tahun_list,
            'notif' => $notif,
        ];

        return view('admin/laporan_konsultasi', $data);
    }
}
