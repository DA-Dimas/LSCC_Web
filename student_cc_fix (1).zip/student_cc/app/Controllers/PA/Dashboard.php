<?php

namespace App\Controllers\PA;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\DosenModel;
use App\Models\MahasiswaModel;
use App\Models\FormKonsultasiModel;
use App\Models\TindakLanjutModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $mahasiswa = new MahasiswaModel();
        $dosen = new DosenModel();
        $konsultasi = new FormKonsultasiModel();
        $tindaklanjut = new TindakLanjutModel();
        $data = [
            'title' => 'Dashboard',
            'mahasiswa' => $mahasiswa->getTotalMahasiswa(),
            'dosen' => $dosen->getTotalKonseler(),
            'konsultasi' => $konsultasi->getTotalKonsultasi(),
            'tindaklanjut' => $tindaklanjut->getTotalTindakLanjut()
        ];
        return view('pa/dashboard', $data);
    }
}
