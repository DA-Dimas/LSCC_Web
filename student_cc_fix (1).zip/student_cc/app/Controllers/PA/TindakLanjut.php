<?php

namespace App\Controllers\PA;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\TindakLanjutModel;
use App\Models\FormKonsultasiModel;

class TindakLanjut extends BaseController
{
    protected $tindakLanjutModel;
    protected $konsultasiModel;

    public function __construct()
    {
        $this->tindakLanjutModel = new TindakLanjutModel();
        $this->konsultasiModel = new FormKonsultasiModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Tindak Lanjut',
            'konsultasi' => $this->konsultasiModel->getMahasiswa()
        ];
        return view('pa/tindaklanjut', $data);
    }

    public function save()
    {
        $data = [
            'id_konsultasi' => $this->request->getPost('id_konsultasi'),
            'tindak_lanjut' => $this->request->getPost('tindak_lanjut'),
            'dibuat_oleh'   => session()->get('username'), // Pastikan session ini ada
        ];

        if ($this->tindakLanjutModel->insert($data)) {
            return redirect()->to('pa/tindaklanjut')->with('success', 'Tindak lanjut berhasil disimpan');
        } else {
            return redirect()->to('pa/tindaklanjut')->with('error', 'Gagal menyimpan tindak lanjut');
        }
    }

}
