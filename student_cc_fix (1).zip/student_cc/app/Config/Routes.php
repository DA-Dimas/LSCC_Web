<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// PUBLIC
$routes->get('/', 'Home::index');
$routes->get('/konselor', 'Home::konselor');

// route login
$routes->get('/login', 'LoginController::index');
$routes->post('/login_action', 'LoginController::login_action');
$routes->get('/logout', 'LoginController::logout');
// PUBLIC

// MAHASISWA
// Janji temu
$routes->get('mahasiswa/janji_temu', 'JanjiTemuMahasiswaController::index', ['filter' => 'mahasiswaFilter']);
$routes->post('mahasiswa/janji_temu', 'JanjiTemuMahasiswaController::index', ['filter' => 'mahasiswaFilter']);
$routes->post('mahasiswa/janji_temu/save', 'JanjiTemuMahasiswaController::save', ['filter' => 'mahasiswaFilter']);

// Laporan Janji temu
$routes->get('mahasiswa/laporan_janji_temu', 'LaporanJanjiTemuController::index', ['filter' => 'mahasiswaFilter']);
$routes->post('mahasiswa/laporan_janji_temu/update/(:segment)', 'LaporanJanjiTemuController::update/$1', ['filter' => 'mahasiswaFilter']);

// MAHASISWA

// ADMIN
// routes admin
$routes->get('admin/dashboard', 'Admin\Dashboard::index', ['filter' => 'adminFilter']);

// CRUD Prodi
$routes->get('admin/prodi', 'Admin\Prodi::index', ['filter' => 'adminFilter']);
// $routes->get('admin/prodi/create', 'Admin\Prodi::create', ['filter' => 'adminFilter']);
$routes->post('admin/prodi/save', 'Admin\Prodi::save', ['filter' => 'adminFilter']);
// $routes->get('admin/prodi/edit/(:segment)', 'Admin\Prodi::edit/$1', ['filter' => 'adminFilter']);
$routes->post('admin/prodi/update/(:segment)', 'Admin\Prodi::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/prodi/delete/(:segment)', 'Admin\Prodi::delete/$1', ['filter' => 'adminFilter']);

// CRUD Kategori Keluhan
$routes->get('admin/kategori', 'Admin\Kategori::index', ['filter' => 'adminFilter']);
// $routes->get('admin/kategori/create', 'Admin\Kategori::create', ['filter' => 'adminFilter']);
$routes->post('admin/kategori/save', 'Admin\Kategori::save', ['filter' => 'adminFilter']);
// $routes->get('admin/kategori/edit/(:segment)', 'Admin\Kategori::edit/$1', ['filter' => 'adminFilter']);
$routes->post('admin/kategori/update/(:segment)', 'Admin\Kategori::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/kategori/delete/(:segment)', 'Admin\Kategori::delete/$1', ['filter' => 'adminFilter']);

// CRUD Mahasiswa
// $routes->get('admin/kelas', 'Admin\Kelas::index', ['filter' => 'adminFilter']);
// $routes->get('admin/kelas/create', 'Admin\Kelas::create', ['filter' => 'adminFilter']);
// $routes->post('admin/kelas/save', 'Admin\Kelas::save', ['filter' => 'adminFilter']);
// $routes->get('admin/kelas/edit/(:segment)', 'Admin\Kelas::edit/$1', ['filter' => 'adminFilter']);
// $routes->post('admin/kelas/update/(:segment)', 'Admin\Kelas::update/$1', ['filter' => 'adminFilter']);
// $routes->get('admin/kelas/delete/(:segment)', 'Admin\Kelas::delete/$1', ['filter' => 'adminFilter']);

// CRUD Mahasiswa
$routes->get('admin/mahasiswa', 'Admin\Mahasiswa::index', ['filter' => 'adminFilter']);
// $routes->get('admin/mahasiswa/create', 'Admin\Mahasiswa::create', ['filter' => 'adminFilter']);
$routes->post('admin/mahasiswa/save', 'Admin\Mahasiswa::save', ['filter' => 'adminFilter']);
$routes->get('admin/mahasiswa/edit/(:segment)', 'Admin\Mahasiswa::edit/$1', ['filter' => 'adminFilter']);
$routes->put('admin/mahasiswa/update/(:segment)', 'Admin\Mahasiswa::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/mahasiswa/delete/(:segment)', 'Admin\Mahasiswa::delete/$1', ['filter' => 'adminFilter']);

// CRUD Dosen
$routes->get('admin/dosen', 'Admin\Dosen::index', ['filter' => 'adminFilter']);
// $routes->get('admin/dosen/create', 'Admin\Dosen::create', ['filter' => 'adminFilter']);
$routes->post('admin/dosen/save', 'Admin\Dosen::save', ['filter' => 'adminFilter']);
$routes->get('admin/dosen/edit/(:segment)', 'Admin\Dosen::edit/$1', ['filter' => 'adminFilter']);
$routes->put('admin/dosen/update/(:segment)', 'Admin\Dosen::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/dosen/delete/(:segment)', 'Admin\Dosen::delete/$1', ['filter' => 'adminFilter']);

// CRUD User
$routes->get('admin/user', 'Admin\User::index', ['filter' => 'adminFilter']);
// $routes->get('admin/user/create', 'Admin\User::create', ['filter' => 'adminFilter']);
$routes->post('admin/user/save', 'Admin\User::save', ['filter' => 'adminFilter']);
$routes->get('admin/user/edit/(:segment)', 'Admin\User::edit/$1', ['filter' => 'adminFilter']);
$routes->put('admin/user/update/(:segment)', 'Admin\User::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/user/delete/(:segment)', 'Admin\User::delete/$1', ['filter' => 'adminFilter']);

// Laporan Konsultasi
$routes->get('admin/laporan_konsultasi', 'Admin\LaporanKonsultasi::index', ['filter' => 'adminFilter']);

// Laporan Janji Temu 
$routes->get('admin/laporan_janji_temu', 'Admin\JanjiTemuAdminController::index', ['filter' => 'adminFilter']);
$routes->post('admin/laporan_janji_temu/update/(:segment)', 'Admin\JanjiTemuAdminController::update/$1', ['filter' => 'adminFilter']);

// ADMIN

// DOSEN/KONSELOR
// routes dosen
$routes->get('dosen/dashboard', 'Dosen\Dashboard::index', ['filter' => 'dosenFilter']);

// Form Konsultasi
$routes->get('dosen/form_konsultasi', 'Dosen\FormKonsultasi::index', ['filter' => 'dosenFilter']);
$routes->post('dosen/form_konsultasi', 'Dosen\FormKonsultasi::index', ['filter' => 'dosenFilter']); // Untuk filter
$routes->post('dosen/form_konsultasi/submit', 'Dosen\FormKonsultasi::submit', ['filter' => 'dosenFilter']); // Untuk menyimpan konsultasi

// Tindaklanjut
$routes->get('dosen/tindaklanjut', 'Dosen\TindakLanjut::index', ['filter' => 'dosenFilter']);
$routes->post('dosen/tindaklanjut/save', 'Dosen\TindakLanjut::save', ['filter' => 'dosenFilter']);

// Approval Janji Temu
$routes->get('dosen/janji_temu', 'Dosen\JanjiTemuDosenController::index', ['filter' => 'dosenFilter']);
$routes->post('dosen/janji_temu/update/(:segment)', 'Dosen\JanjiTemuDosenController::update/$1', ['filter' => 'dosenFilter']);
$routes->post('dosen/janji_temu/konsul/(:segment)', 'Dosen\JanjiTemuDosenController::konsul/$1', ['filter' => 'dosenFilter']);

// DOSEN/KONSELOR

// PEMBIMBING AKADEMIK
// routes dosen
$routes->get('pa/dashboard', 'PA\Dashboard::index', ['filter' => 'paFilter']);

// Tindaklanjut
$routes->get('pa/tindaklanjut', 'PA\TindakLanjut::index', ['filter' => 'paFilter']);
$routes->post('pa/tindaklanjut/save', 'PA\TindakLanjut::save', ['filter' => 'paFilter']);

// PEMBIMBING AKADEMIK